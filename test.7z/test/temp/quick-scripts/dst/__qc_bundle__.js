
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/Cell');
require('./assets/Script/Circle');
require('./assets/Script/GameField');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Cell.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '93f68rzHqxJY5it62LGw3mz', 'Cell');
// Script/Cell.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Cell = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//TODO переделать алгоритмы генерации. переделать полностью архитекутуру.
var Cell = /** @class */ (function (_super) {
    __extends(Cell, _super);
    //клетка - объект клетки
    function Cell() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //TODO релиз очистить от ненужных переменных и легаси комментариев
        //клетка генератор?
        _this.generator = false;
        //клетка активна? 
        _this.activeself = true;
        //номер строки,где лежит клетка
        _this.irow = 0;
        //номер столбца ,где лежит клетка
        _this.jcolumn = 0;
        //итерация появления фишек
        _this.iter = 0.2;
        //дельта тайм
        _this._timer = 0;
        //кружок для инстантинейта
        _this.Circle = null;
        //кружок в клетке в данный момент
        _this._circle = null;
        //узел с права
        _this.CellRigh = null;
        //узел с лева
        _this.CellLeft = null;
        //узел с верху
        _this.CellTop = null;
        //узел с снизу
        _this.CellBottom = null;
        return _this;
    }
    Cell_1 = Cell;
    Cell.prototype.onLoad = function () {
        //первые шарики появляются тут
        this.createCircle();
    };
    //TODO эту всю логику нужно перенести в GameField т.к.
    //из-за того,что апдейт одновременно выполняется в куче клетках 
    //,не нормально анимировать,не оптимизировать.
    Cell.prototype.update = function (dt) {
        if (this.activeself) {
            // генерация в клетках генераторах
            this.createCircle();
            this._timer += dt;
            //каждую итерацию вызываем движение вниз/вправо, TODO, настроить нормальную анимацию
            //TODO заблокировать поле от кликов,пока идёт генерация.
            if (this._timer >= this.iter) {
                if (this._circle != null) {
                    //TODO выделить повторный код. 
                    if (this.CellBottom != null)
                        if (!this.circleMove(this.CellBottom, this.CellBottom.getComponent(Cell_1))) {
                            if (this.CellRigh != null)
                                if (this.circleMove(this.CellRigh, this.CellRigh.getComponent(Cell_1))) { }
                        }
                }
                this._timer = 0;
            }
        }
    };
    Cell.prototype.createCircle = function () {
        if (this.generator && this._circle == null) {
            this._circle = cc.instantiate(this.Circle);
            this._circle.setParent(this.node);
            this._circle.setPosition(0, 0);
            //cc.log(this.GameField.iсells);
        }
    };
    //p.s. в методе
    //нарушен принцип единственной ответственности.
    Cell.prototype.circleMove = function (Cell, CellComponent) {
        if (Cell != null && CellComponent._circle == null && CellComponent.activeself) {
            var animator = cc.tween;
            CellComponent._circle = this._circle;
            CellComponent._circle.parent = CellComponent.node;
            this._circle = null;
            animator(CellComponent._circle)
                .parallel(animator().to(this.iter - 0.01, { scale: 1 }), animator().to(this.iter - 0.01, { position: cc.v2(0, 0) }))
                .call(function () {
                return;
            })
                .start();
            return true;
        }
        return false;
    };
    Cell.prototype.lateUpdate = function (dt) {
    };
    var Cell_1;
    __decorate([
        property
    ], Cell.prototype, "generator", void 0);
    __decorate([
        property
    ], Cell.prototype, "activeself", void 0);
    __decorate([
        property
    ], Cell.prototype, "iter", void 0);
    __decorate([
        property(cc.Prefab)
    ], Cell.prototype, "Circle", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellRigh", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellLeft", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellTop", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellBottom", void 0);
    Cell = Cell_1 = __decorate([
        ccclass
        //клетка - объект клетки
    ], Cell);
    return Cell;
}(cc.Component));
exports.Cell = Cell;
//клетка на переделку.
var Cell0 = /** @class */ (function () {
    function Cell0(iRow, iColumn) {
        this.generator = false;
        this.activeself = true;
        this.irow = 0;
        this.jcolumn = 0;
        this._circle = null;
        this.irow = iRow;
        this.jcolumn = iColumn;
    }
    return Cell0;
}());

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDZWxsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDTSxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUN4Qyx5RUFBeUU7QUFHM0U7SUFBMEIsd0JBQVk7SUFEdEMsd0JBQXdCO0lBQ3hCO1FBQUEscUVBK0ZDO1FBOUZHLGtFQUFrRTtRQUVsRSxBQUNBLG1CQURtQjtRQUNuQixlQUFTLEdBQVksS0FBSyxDQUFDO1FBRTNCLEFBQ0Esa0JBRGtCO1FBQ2xCLGdCQUFVLEdBQVksSUFBSSxDQUFDO1FBQzNCLCtCQUErQjtRQUMvQixVQUFJLEdBQVEsQ0FBQyxDQUFDO1FBQ2QsaUNBQWlDO1FBQ2pDLGFBQU8sR0FBUSxDQUFDLENBQUM7UUFDakIsMEJBQTBCO1FBRTFCLFVBQUksR0FBVyxHQUFHLENBQUM7UUFDbkIsYUFBYTtRQUNiLFlBQU0sR0FBVyxDQUFDLENBQUM7UUFFbkIsQUFDQSwwQkFEMEI7UUFDMUIsWUFBTSxHQUFjLElBQUksQ0FBQztRQUN6QixpQ0FBaUM7UUFDakMsYUFBTyxHQUFZLElBQUksQ0FBQztRQUV4QixBQUNBLGNBRGM7UUFDZCxjQUFRLEdBQVksSUFBSSxDQUFDO1FBRXpCLEFBQ0EsYUFEYTtRQUNiLGNBQVEsR0FBWSxJQUFJLENBQUM7UUFFdkIsQUFDRixjQURnQjtRQUNoQixhQUFPLEdBQVksSUFBSSxDQUFDO1FBRXRCLEFBQ0YsY0FEZ0I7UUFDaEIsZ0JBQVUsR0FBWSxJQUFJLENBQUM7O0lBOEQvQixDQUFDO2FBL0ZZLElBQUk7SUFrQ2IscUJBQU0sR0FBTjtRQUNJLDhCQUE4QjtRQUM5QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUNELHNEQUFzRDtJQUN0RCxnRUFBZ0U7SUFDaEUsOENBQThDO0lBRTlDLHFCQUFNLEdBQU4sVUFBUSxFQUFFO1FBQ04sSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFHO1lBQ2xCLGtDQUFrQztZQUNsQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDcEIsSUFBSSxDQUFDLE1BQU0sSUFBRSxFQUFFLENBQUM7WUFDaEIsb0ZBQW9GO1lBQ3BGLHdEQUF3RDtZQUN4RCxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUUsSUFBSSxDQUFDLElBQUksRUFBRTtnQkFDeEIsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFFLElBQUksRUFBRTtvQkFDaEIsK0JBQStCO29CQUNuQyxJQUFJLElBQUksQ0FBQyxVQUFVLElBQUUsSUFBSTt3QkFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxNQUFJLENBQUMsQ0FBQyxFQUFFOzRCQUN2RSxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUUsSUFBSTtnQ0FBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxNQUFJLENBQUMsQ0FBQyxFQUFDLEdBQUU7eUJBQXdCO2lCQUMzSDtnQkFDRCxJQUFJLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQzthQUNyQjtTQUNKO0lBQ0wsQ0FBQztJQUVELDJCQUFZLEdBQVo7UUFDSSxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE9BQU8sSUFBRSxJQUFJLEVBQUU7WUFDdEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBRS9CLGdDQUFnQztTQUNuQztJQUNMLENBQUM7SUFDRCxlQUFlO0lBQ2YsK0NBQStDO0lBQy9DLHlCQUFVLEdBQVYsVUFBVyxJQUFJLEVBQUUsYUFBYTtRQUMxQixJQUFJLElBQUksSUFBRSxJQUFJLElBQUksYUFBYSxDQUFDLE9BQU8sSUFBRyxJQUFJLElBQUksYUFBYSxDQUFDLFVBQVUsRUFBRTtZQUN4RSxJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDO1lBQ3hCLGFBQWEsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUNyQyxhQUFhLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDO1lBQ2xELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDO2lCQUM5QixRQUFRLENBQ0wsUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUMsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQzNDLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFDLElBQUksRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQzNEO2lCQUNBLElBQUksQ0FBQztnQkFDRixPQUFPO1lBQ1gsQ0FBQyxDQUFDO2lCQUNELEtBQUssRUFBRSxDQUFBO1lBQ1IsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUFDLE9BQU8sS0FBSyxDQUFDO0lBQ25CLENBQUM7SUFFRCx5QkFBVSxHQUFWLFVBQVcsRUFBRTtJQUViLENBQUM7O0lBekZEO1FBRkMsUUFBUTsyQ0FFa0I7SUFHM0I7UUFGQyxRQUFROzRDQUVrQjtJQU8zQjtRQURDLFFBQVE7c0NBQ1U7SUFLbkI7UUFGQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzt3Q0FFSztJQUt6QjtRQUZDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzBDQUVPO0lBR3pCO1FBRkMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7MENBRU87SUFHekI7UUFGQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzt5Q0FFTTtJQUd4QjtRQUZDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzRDQUVTO0lBakNsQixJQUFJO1FBRmhCLE9BQU87UUFDUix3QkFBd0I7T0FDWCxJQUFJLENBK0ZoQjtJQUFELFdBQUM7Q0EvRkQsQUErRkMsQ0EvRnlCLEVBQUUsQ0FBQyxTQUFTLEdBK0ZyQztBQS9GWSxvQkFBSTtBQWlHakIsc0JBQXNCO0FBQ3RCO0lBUUksZUFBWSxJQUFZLEVBQUUsT0FBZTtRQU56QyxjQUFTLEdBQVksS0FBSyxDQUFDO1FBQzNCLGVBQVUsR0FBWSxJQUFJLENBQUM7UUFDbEIsU0FBSSxHQUFRLENBQUMsQ0FBQztRQUNkLFlBQU8sR0FBUSxDQUFDLENBQUM7UUFDMUIsWUFBTyxHQUFZLElBQUksQ0FBQztRQUdwQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztJQUMzQixDQUFDO0lBRUwsWUFBQztBQUFELENBYkEsQUFhQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG4gIC8vVE9ETyDQv9C10YDQtdC00LXQu9Cw0YLRjCDQsNC70LPQvtGA0LjRgtC80Ysg0LPQtdC90LXRgNCw0YbQuNC4LiDQv9C10YDQtdC00LXQu9Cw0YLRjCDQv9C+0LvQvdC+0YHRgtGM0Y4g0LDRgNGF0LjRgtC10LrRg9GC0YPRgNGDLlxyXG5AY2NjbGFzc1xyXG4vL9C60LvQtdGC0LrQsCAtINC+0LHRitC10LrRgiDQutC70LXRgtC60LhcclxuZXhwb3J0IGNsYXNzIENlbGwgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG4gICAgLy9UT0RPINGA0LXQu9C40Lcg0L7Rh9C40YHRgtC40YLRjCDQvtGCINC90LXQvdGD0LbQvdGL0YUg0L/QtdGA0LXQvNC10L3QvdGL0YUg0Lgg0LvQtdCz0LDRgdC4INC60L7QvNC80LXQvdGC0LDRgNC40LXQslxyXG4gICAgQHByb3BlcnR5XHJcbiAgICAvL9C60LvQtdGC0LrQsCDQs9C10L3QtdGA0LDRgtC+0YA/XHJcbiAgICBnZW5lcmF0b3I6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEBwcm9wZXJ0eVxyXG4gICAgLy/QutC70LXRgtC60LAg0LDQutGC0LjQstC90LA/IFxyXG4gICAgYWN0aXZlc2VsZjogYm9vbGVhbiA9IHRydWU7XHJcbiAgICAvL9C90L7QvNC10YAg0YHRgtGA0L7QutC4LNCz0LTQtSDQu9C10LbQuNGCINC60LvQtdGC0LrQsFxyXG4gICAgaXJvdzpudW1iZXI9MDtcclxuICAgIC8v0L3QvtC80LXRgCDRgdGC0L7Qu9Cx0YbQsCAs0LPQtNC1INC70LXQttC40YIg0LrQu9C10YLQutCwXHJcbiAgICBqY29sdW1uOm51bWJlcj0wO1xyXG4gICAgLy/QuNGC0LXRgNCw0YbQuNGPINC/0L7Rj9Cy0LvQtdC90LjRjyDRhNC40YjQtdC6XHJcbiAgICBAcHJvcGVydHlcclxuICAgIGl0ZXI6IG51bWJlciA9IDAuMjtcclxuICAgIC8v0LTQtdC70YzRgtCwINGC0LDQudC8XHJcbiAgICBfdGltZXI6IG51bWJlciA9IDA7XHJcbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxyXG4gICAgLy/QutGA0YPQttC+0Log0LTQu9GPINC40L3RgdGC0LDQvdGC0LjQvdC10LnRgtCwXHJcbiAgICBDaXJjbGU6IGNjLlByZWZhYiA9IG51bGw7XHJcbiAgICAvL9C60YDRg9C20L7QuiDQsiDQutC70LXRgtC60LUg0LIg0LTQsNC90L3Ri9C5INC80L7QvNC10L3RglxyXG4gICAgX2NpcmNsZTogY2MuTm9kZSA9IG51bGw7XHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIC8v0YPQt9C10Lsg0YEg0L/RgNCw0LLQsFxyXG4gICAgQ2VsbFJpZ2g6IGNjLk5vZGUgPSBudWxsO1xyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICAvL9GD0LfQtdC7INGBINC70LXQstCwXHJcbiAgICBDZWxsTGVmdDogY2MuTm9kZSA9IG51bGw7XHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgICAgLy/Rg9C30LXQuyDRgSDQstC10YDRhdGDXHJcbiAgICBDZWxsVG9wOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgICAvL9GD0LfQtdC7INGBINGB0L3QuNC30YNcclxuICAgIENlbGxCb3R0b206IGNjLk5vZGUgPSBudWxsO1xyXG4gICAgb25Mb2FkKCkge1xyXG4gICAgICAgIC8v0L/QtdGA0LLRi9C1INGI0LDRgNC40LrQuCDQv9C+0Y/QstC70Y/RjtGC0YHRjyDRgtGD0YJcclxuICAgICAgICB0aGlzLmNyZWF0ZUNpcmNsZSgpO1xyXG4gICAgfVxyXG4gICAgLy9UT0RPINGN0YLRgyDQstGB0Y4g0LvQvtCz0LjQutGDINC90YPQttC90L4g0L/QtdGA0LXQvdC10YHRgtC4INCyIEdhbWVGaWVsZCDRgi7Qui5cclxuICAgIC8v0LjQty3Qt9CwINGC0L7Qs9C+LNGH0YLQviDQsNC/0LTQtdC50YIg0L7QtNC90L7QstGA0LXQvNC10L3QvdC+INCy0YvQv9C+0LvQvdGP0LXRgtGB0Y8g0LIg0LrRg9GH0LUg0LrQu9C10YLQutCw0YUgXHJcbiAgICAvLyzQvdC1INC90L7RgNC80LDQu9GM0L3QviDQsNC90LjQvNC40YDQvtCy0LDRgtGMLNC90LUg0L7Qv9GC0LjQvNC40LfQuNGA0L7QstCw0YLRjC5cclxuIFxyXG4gICAgdXBkYXRlIChkdCkge1xyXG4gICAgICAgIGlmICh0aGlzLmFjdGl2ZXNlbGYpICB7XHJcbiAgICAgICAgICAgIC8vINCz0LXQvdC10YDQsNGG0LjRjyDQsiDQutC70LXRgtC60LDRhSDQs9C10L3QtdGA0LDRgtC+0YDQsNGFXHJcbiAgICAgICAgICAgIHRoaXMuY3JlYXRlQ2lyY2xlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3RpbWVyKz1kdDtcclxuICAgICAgICAgICAgLy/QutCw0LbQtNGD0Y4g0LjRgtC10YDQsNGG0LjRjiDQstGL0LfRi9Cy0LDQtdC8INC00LLQuNC20LXQvdC40LUg0LLQvdC40Lcv0LLQv9GA0LDQstC+LCBUT0RPLCDQvdCw0YHRgtGA0L7QuNGC0Ywg0L3QvtGA0LzQsNC70YzQvdGD0Y4g0LDQvdC40LzQsNGG0LjRjlxyXG4gICAgICAgICAgICAvL1RPRE8g0LfQsNCx0LvQvtC60LjRgNC+0LLQsNGC0Ywg0L/QvtC70LUg0L7RgiDQutC70LjQutC+0LIs0L/QvtC60LAg0LjQtNGR0YIg0LPQtdC90LXRgNCw0YbQuNGPLlxyXG4gICAgICAgICAgICBpZiAodGhpcy5fdGltZXI+PXRoaXMuaXRlcikge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2NpcmNsZSE9bnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL1RPRE8g0LLRi9C00LXQu9C40YLRjCDQv9C+0LLRgtC+0YDQvdGL0Lkg0LrQvtC0LiBcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5DZWxsQm90dG9tIT1udWxsKVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5jaXJjbGVNb3ZlKHRoaXMuQ2VsbEJvdHRvbSwgdGhpcy5DZWxsQm90dG9tLmdldENvbXBvbmVudChDZWxsKSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuQ2VsbFJpZ2ghPW51bGwpIGlmICh0aGlzLmNpcmNsZU1vdmUodGhpcy5DZWxsUmlnaCwgdGhpcy5DZWxsUmlnaC5nZXRDb21wb25lbnQoQ2VsbCkpKXt9ICAgICAgICAgICAgICAgICAgICAgICB9IFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl90aW1lcj0wOyAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY3JlYXRlQ2lyY2xlKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmdlbmVyYXRvciAmJiB0aGlzLl9jaXJjbGU9PW51bGwpIHtcclxuICAgICAgICAgICAgdGhpcy5fY2lyY2xlID0gY2MuaW5zdGFudGlhdGUodGhpcy5DaXJjbGUpO1xyXG4gICAgICAgICAgICB0aGlzLl9jaXJjbGUuc2V0UGFyZW50KHRoaXMubm9kZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NpcmNsZS5zZXRQb3NpdGlvbigwLCAwKTtcclxuICAgICAgICAgXHJcbiAgICAgICAgICAgIC8vY2MubG9nKHRoaXMuR2FtZUZpZWxkLmnRgWVsbHMpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8vcC5zLiDQsiDQvNC10YLQvtC00LVcclxuICAgIC8v0L3QsNGA0YPRiNC10L0g0L/RgNC40L3RhtC40L8g0LXQtNC40L3RgdGC0LLQtdC90L3QvtC5INC+0YLQstC10YLRgdGC0LLQtdC90L3QvtGB0YLQuC5cclxuICAgIGNpcmNsZU1vdmUoQ2VsbCwgQ2VsbENvbXBvbmVudCl7XHJcbiAgICAgICAgaWYgKENlbGwhPW51bGwgJiYgQ2VsbENvbXBvbmVudC5fY2lyY2xlID09bnVsbCAmJiBDZWxsQ29tcG9uZW50LmFjdGl2ZXNlbGYpIHtcclxuICAgICAgICAgICAgbGV0IGFuaW1hdG9yID0gY2MudHdlZW47XHJcbiAgICAgICAgICAgIENlbGxDb21wb25lbnQuX2NpcmNsZSA9IHRoaXMuX2NpcmNsZTtcclxuICAgICAgICAgICAgQ2VsbENvbXBvbmVudC5fY2lyY2xlLnBhcmVudCA9IENlbGxDb21wb25lbnQubm9kZTtcclxuICAgICAgICAgICAgdGhpcy5fY2lyY2xlID0gbnVsbDtcclxuICAgICAgICAgICAgYW5pbWF0b3IoQ2VsbENvbXBvbmVudC5fY2lyY2xlKVxyXG4gICAgICAgICAgICAucGFyYWxsZWwoXHJcbiAgICAgICAgICAgICAgICBhbmltYXRvcigpLnRvKHRoaXMuaXRlci0wLjAxLCB7IHNjYWxlOiAxIH0pLFxyXG4gICAgICAgICAgICAgICAgYW5pbWF0b3IoKS50byh0aGlzLml0ZXItMC4wMSwgeyBwb3NpdGlvbjogY2MudjIoMCwgMCkgfSlcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAuY2FsbCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5zdGFydCgpXHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH0gcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBsYXRlVXBkYXRlKGR0KSB7XHJcbiAgICAgICBcclxuICAgIH1cclxuXHJcbn1cclxuXHJcbi8v0LrQu9C10YLQutCwINC90LAg0L/QtdGA0LXQtNC10LvQutGDLlxyXG5jbGFzcyBDZWxsMCB7XHJcblxyXG4gICAgZ2VuZXJhdG9yOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBhY3RpdmVzZWxmOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHJlYWRvbmx5IGlyb3c6bnVtYmVyPTA7XHJcbiAgICByZWFkb25seSBqY29sdW1uOm51bWJlcj0wO1xyXG4gICAgX2NpcmNsZTogY2MuTm9kZSA9IG51bGw7XHJcbiAgIFxyXG4gICAgY29uc3RydWN0b3IoaVJvdzogbnVtYmVyLCBpQ29sdW1uOiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLmlyb3cgPSBpUm93O1xyXG4gICAgICAgIHRoaXMuamNvbHVtbiA9IGlDb2x1bW47XHJcbiAgICB9XHJcblxyXG59Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Circle.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7dbc7eE2d1AgKeAG34Dn73t', 'Circle');
// Script/Circle.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Circle = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//класс кружка
var Circle = /** @class */ (function (_super) {
    __extends(Circle, _super);
    function Circle() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //спрайты кружков
        _this.sprite = [];
        //тип фишки
        _this.CircleType = 0;
        return _this;
    }
    //подписываемся на событие клика мышки
    //подумать,где его лучше обрабатывать, может быть в Cell
    Circle.prototype.onLoad = function () {
        this.node.on('mousedown', this.mousedown, this);
    };
    //обрабатываем клик мышки
    //
    Circle.prototype.mousedown = function () {
        //this.wasClick=true;
        this.destroyCircle();
    };
    Circle.prototype.destroyCircle = function () {
        //уничтожение фишки 
        var cell = this.node.getParent();
        cell.getComponent("Cell")._circle = null;
        this.node.destroy();
    };
    Circle.prototype.start = function () {
        //тут случайным образом распределяем спрайты при их появление на сцене 
        var node = new cc.Node('Sprite');
        var sp = node.addComponent(cc.Sprite);
        sp.spriteFrame = this.sprite[Math.floor((Math.random() * 6) + 1)];
        node.parent = this.node;
    };
    __decorate([
        property(cc.SpriteFrame)
    ], Circle.prototype, "sprite", void 0);
    __decorate([
        property
    ], Circle.prototype, "CircleType", void 0);
    Circle = __decorate([
        ccclass
    ], Circle);
    return Circle;
}(cc.Component));
exports.Circle = Circle;
//тип фишки
var typeCircle;
(function (typeCircle) {
    typeCircle[typeCircle["normal"] = 0] = "normal";
    typeCircle[typeCircle["lightningHorizont"] = 1] = "lightningHorizont";
    typeCircle[typeCircle["lightningVertical"] = 2] = "lightningVertical";
    typeCircle[typeCircle["rainbowBall"] = 3] = "rainbowBall";
})(typeCircle || (typeCircle = {}));

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDaXJjbGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQix3RUFBd0U7QUFDeEUsbUJBQW1CO0FBQ25CLGtGQUFrRjtBQUNsRiw4QkFBOEI7QUFDOUIsa0ZBQWtGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRzVFLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBQ3hDLGNBQWM7QUFFZDtJQUE0QiwwQkFBWTtJQUF4QztRQUFBLHFFQXFDQztRQW5DRyxpQkFBaUI7UUFFakIsWUFBTSxHQUFzQixFQUFFLENBQUM7UUFFL0IsQUFDQSxXQURXO1FBQ1gsZ0JBQVUsR0FBZSxDQUFDLENBQUM7O0lBOEIvQixDQUFDO0lBN0JHLHNDQUFzQztJQUN0Qyx3REFBd0Q7SUFDeEQsdUJBQU0sR0FBTjtRQUNFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFRCx5QkFBeUI7SUFDekIsRUFBRTtJQUNGLDBCQUFTLEdBQVQ7UUFDRSxxQkFBcUI7UUFDckIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFFRCw4QkFBYSxHQUFiO1FBQ0Usb0JBQW9CO1FBQ3BCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDakMsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEdBQUMsSUFBSSxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7SUFFdEIsQ0FBQztJQUVELHNCQUFLLEdBQUw7UUFDRSx1RUFBdUU7UUFDdkUsSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2pDLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RDLEVBQUUsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzFCLENBQUM7SUEvQkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQzswQ0FDTTtJQUcvQjtRQUZDLFFBQVE7OENBRWtCO0lBUGxCLE1BQU07UUFEbEIsT0FBTztPQUNLLE1BQU0sQ0FxQ2xCO0lBQUQsYUFBQztDQXJDRCxBQXFDQyxDQXJDMkIsRUFBRSxDQUFDLFNBQVMsR0FxQ3ZDO0FBckNZLHdCQUFNO0FBc0NuQixXQUFXO0FBQ1gsSUFBSyxVQUtKO0FBTEQsV0FBSyxVQUFVO0lBQ2IsK0NBQVUsQ0FBQTtJQUNWLHFFQUFpQixDQUFBO0lBQ2pCLHFFQUFpQixDQUFBO0lBQ2pCLHlEQUFXLENBQUE7QUFDYixDQUFDLEVBTEksVUFBVSxLQUFWLFVBQVUsUUFLZCIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmltcG9ydCBHYW1lRmllbGQgZnJvbSBcIi4vR2FtZUZpZWxkXCI7XHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG4gIC8v0LrQu9Cw0YHRgSDQutGA0YPQttC60LBcclxuICBAY2NjbGFzc1xyXG4gIGV4cG9ydCBjbGFzcyBDaXJjbGUgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgICAgLy/RgdC/0YDQsNC50YLRiyDQutGA0YPQttC60L7QslxyXG4gICAgICBAcHJvcGVydHkoY2MuU3ByaXRlRnJhbWUpXHJcbiAgICAgIHNwcml0ZTogY2MuU3ByaXRlRnJhbWUgW10gPSBbXTtcclxuICAgICAgQHByb3BlcnR5XHJcbiAgICAgIC8v0YLQuNC/INGE0LjRiNC60LhcclxuICAgICAgQ2lyY2xlVHlwZTogdHlwZUNpcmNsZSA9IDA7XHJcbiAgICAgIC8v0L/QvtC00L/QuNGB0YvQstCw0LXQvNGB0Y8g0L3QsCDRgdC+0LHRi9GC0LjQtSDQutC70LjQutCwINC80YvRiNC60LhcclxuICAgICAgLy/Qv9C+0LTRg9C80LDRgtGMLNCz0LTQtSDQtdCz0L4g0LvRg9GH0YjQtSDQvtCx0YDQsNCx0LDRgtGL0LLQsNGC0YwsINC80L7QttC10YIg0LHRi9GC0Ywg0LIgQ2VsbFxyXG4gICAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMubm9kZS5vbignbW91c2Vkb3duJywgdGhpcy5tb3VzZWRvd24sIHRoaXMpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvL9C+0LHRgNCw0LHQsNGC0YvQstCw0LXQvCDQutC70LjQuiDQvNGL0YjQutC4XHJcbiAgICAgIC8vXHJcbiAgICAgIG1vdXNlZG93bigpIHtcclxuICAgICAgICAvL3RoaXMud2FzQ2xpY2s9dHJ1ZTtcclxuICAgICAgICB0aGlzLmRlc3Ryb3lDaXJjbGUoKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgZGVzdHJveUNpcmNsZSgpe1xyXG4gICAgICAgIC8v0YPQvdC40YfRgtC+0LbQtdC90LjQtSDRhNC40YjQutC4IFxyXG4gICAgICAgIHZhciBjZWxsID0gdGhpcy5ub2RlLmdldFBhcmVudCgpO1xyXG4gICAgICAgIGNlbGwuZ2V0Q29tcG9uZW50KFwiQ2VsbFwiKS5fY2lyY2xlPW51bGw7XHJcbiAgICAgICAgdGhpcy5ub2RlLmRlc3Ryb3koKTtcclxuICAgICAgXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICAvL9GC0YPRgiDRgdC70YPRh9Cw0LnQvdGL0Lwg0L7QsdGA0LDQt9C+0Lwg0YDQsNGB0L/RgNC10LTQtdC70Y/QtdC8INGB0L/RgNCw0LnRgtGLINC/0YDQuCDQuNGFINC/0L7Rj9Cy0LvQtdC90LjQtSDQvdCwINGB0YbQtdC90LUgXHJcbiAgICAgICAgdmFyIG5vZGUgPSBuZXcgY2MuTm9kZSgnU3ByaXRlJyk7XHJcbiAgICAgICAgdmFyIHNwID0gbm9kZS5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICBzcC5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByaXRlW01hdGguZmxvb3IoKE1hdGgucmFuZG9tKCkgKiA2KSArIDEpXTtcclxuICAgICAgICBub2RlLnBhcmVudCA9IHRoaXMubm9kZTtcclxuICAgICAgfVxyXG4gICAgIFxyXG4gIH0gXHJcbiAgLy/RgtC40L8g0YTQuNGI0LrQuFxyXG4gIGVudW0gdHlwZUNpcmNsZSB7XHJcbiAgICBub3JtYWwgPSAwLFxyXG4gICAgbGlnaHRuaW5nSG9yaXpvbnQsXHJcbiAgICBsaWdodG5pbmdWZXJ0aWNhbCxcclxuICAgIHJhaW5ib3dCYWxsLFxyXG4gIH1cclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameField.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bfa611mBN1Ato8bmVTiNiGw', 'GameField');
// Script/GameField.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Circle_1 = require("./Circle");
var Cell_1 = require("./Cell");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameField = /** @class */ (function (_super) {
    __extends(GameField, _super);
    //Singleton - одиночка, управлаяющая игровым полем, 
    //скорей всего тут будет и vie, мне пока тяжело переосмыслить некоторые вещи из
    //кокоса, немного рефлексии, которая должна помочь:
    //изначально я планировал создать двухмерный массив клеток [][], но в отличие
    //от юнити -почему-то в кокосе нельзя через инспектор заполнять двухмерный массив объектами
    //(или я туплю?), инстантинейтить круглешки в клетку и обращаться к ним
    //как к дочерним элементам, хранить и получать все индексы по клику
    // (по клетке,либо по круглишку).
    //Так бы было и проще уничтожать молниями и делать прочие вещи.
    //Когда не получилось с двухмерным массивом
    //размышления дошли до тупой бизнес логики - просто смотреть узлы и от этого и играть,
    //вот,сейчас опять думаю - взять поле через getChildByUuid и переписать весь алгоритм.
    //
    function GameField() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //кружок для инстантинейта
        _this.Circle = null;
        _this.column = 9;
        _this.row = 9;
        //количество активных клеток
        //,когда перепишу алгоритм генерации - не понадобится.
        _this.countActiveCells = 60;
        _this.countCells = 81;
        _this.iсells = 0;
        //поле клеток
        _this.Cells = [
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
        ];
        return _this;
    }
    GameField.prototype.onLoad = function () {
        //заполняем поле клетками
        var i = 0;
        var j = 0;
        var k = 0;
        for (j = 0; j < this.Cells.length; j++) {
            for (i = 0; i < this.Cells[j].length; i++) {
                this.Cells[j][i] = this.node.getChildByName("Cell" + k.toString()).getComponent(Cell_1.Cell);
                this.Cells[j][i].jcolumn = j;
                this.Cells[j][i].irow = i;
                k++;
            }
        }
    };
    GameField.prototype.generatorCircle = function () {
    };
    GameField.prototype.createCircle = function (Cell) {
        if (Cell.generator && Cell._circle == null) {
            Cell._circle = cc.instantiate(this.Circle);
            Cell._circle.setParent(this.node);
            Cell._circle.setPosition(0, 0);
            Cell._circle.getComponent(Circle_1.Circle).GameField = Cell.GameField;
            Cell.GameField.iсells++;
        }
    };
    //ToDo - событие, проверять полное поле - останавливать генерацию,
    //когда высыпались фишку, разрушать и создавать молнии - потом снова продолжать
    //генерацию.
    //иницилизировать событие на downmouse - прорить ряд и ответить.
    //горизонтальная молния
    GameField.prototype.createLightningHorizont = function () {
    };
    //вертикальная молния
    GameField.prototype.createLightningVertical = function () {
    };
    //высыпались три в ряд
    GameField.prototype.threeInArow = function () {
    };
    GameField.prototype.createRainbowBall = function () {
    };
    GameField.prototype.start = function () {
    };
    GameField.prototype.update = function (dt) {
    };
    __decorate([
        property(cc.Prefab)
    ], GameField.prototype, "Circle", void 0);
    __decorate([
        property
    ], GameField.prototype, "column", void 0);
    __decorate([
        property
    ], GameField.prototype, "row", void 0);
    __decorate([
        property
    ], GameField.prototype, "countActiveCells", void 0);
    __decorate([
        property
    ], GameField.prototype, "countCells", void 0);
    __decorate([
        property
    ], GameField.prototype, "i\u0441ells", void 0);
    GameField = __decorate([
        ccclass
        //Singleton - одиночка, управлаяющая игровым полем, 
        //скорей всего тут будет и vie, мне пока тяжело переосмыслить некоторые вещи из
        //кокоса, немного рефлексии, которая должна помочь:
        //изначально я планировал создать двухмерный массив клеток [][], но в отличие
        //от юнити -почему-то в кокосе нельзя через инспектор заполнять двухмерный массив объектами
        //(или я туплю?), инстантинейтить круглешки в клетку и обращаться к ним
        //как к дочерним элементам, хранить и получать все индексы по клику
        // (по клетке,либо по круглишку).
        //Так бы было и проще уничтожать молниями и делать прочие вещи.
        //Когда не получилось с двухмерным массивом
        //размышления дошли до тупой бизнес логики - просто смотреть узлы и от этого и играть,
        //вот,сейчас опять думаю - взять поле через getChildByUuid и переписать весь алгоритм.
        //
    ], GameField);
    return GameField;
}(cc.Component));
exports.default = GameField;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHYW1lRmllbGQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsbUNBQWtDO0FBQ2xDLCtCQUE4QjtBQUN4QixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQW1CMUM7SUFBdUMsNkJBQVk7SUFmbkQsb0RBQW9EO0lBRXBELCtFQUErRTtJQUMvRSxtREFBbUQ7SUFDbkQsNkVBQTZFO0lBQzdFLDJGQUEyRjtJQUMzRix1RUFBdUU7SUFDdkUsbUVBQW1FO0lBQ25FLGlDQUFpQztJQUNqQywrREFBK0Q7SUFDL0QsMkNBQTJDO0lBQzNDLHNGQUFzRjtJQUN0RixzRkFBc0Y7SUFDdEYsRUFBRTtJQUVGO1FBQUEscUVBNEZDO1FBeEZHLDBCQUEwQjtRQUUxQixZQUFNLEdBQWMsSUFBSSxDQUFDO1FBRXpCLFlBQU0sR0FBYSxDQUFDLENBQUM7UUFFckIsU0FBRyxHQUFXLENBQUMsQ0FBQztRQUVoQixBQUVBLDRCQUY0QjtRQUM1QixzREFBc0Q7UUFDdEQsc0JBQWdCLEdBQVcsRUFBRSxDQUFDO1FBRTlCLGdCQUFVLEdBQVUsRUFBRSxDQUFDO1FBRXZCLFlBQU0sR0FBVyxDQUFDLENBQUM7UUFDbkIsYUFBYTtRQUNiLFdBQUssR0FBVztZQUNaLENBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLENBQUM7WUFDOUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksQ0FBQztZQUM5QyxDQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxDQUFDO1lBQzlDLENBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLENBQUM7WUFDOUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksQ0FBQztZQUM5QyxDQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxDQUFDO1lBQzlDLENBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLENBQUM7WUFDOUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksQ0FBQztTQUNqRCxDQUFDOztJQStETixDQUFDO0lBN0RHLDBCQUFNLEdBQU47UUFDRSx5QkFBeUI7UUFDekIsSUFBSSxDQUFDLEdBQVMsQ0FBQyxDQUFDO1FBQ2hCLElBQUksQ0FBQyxHQUFTLENBQUMsQ0FBQztRQUNoQixJQUFJLENBQUMsR0FBUyxDQUFDLENBQUM7UUFDaEIsS0FBSyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBQyxDQUFDLEVBQUUsRUFBRztZQUNqQyxLQUFJLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNqQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBSSxDQUFDLENBQUM7Z0JBQ3RGLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDO2dCQUMxQixDQUFDLEVBQUUsQ0FBQzthQUNQO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsbUNBQWUsR0FBZjtJQUdBLENBQUM7SUFFRCxnQ0FBWSxHQUFaLFVBQWEsSUFBSTtRQUNiLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFFLElBQUksRUFBRTtZQUN0QyxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzNDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsZUFBTSxDQUFDLENBQUMsU0FBUyxHQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7WUFDNUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztTQUMzQjtJQUNMLENBQUM7SUFFRCxrRUFBa0U7SUFDbEUsK0VBQStFO0lBQy9FLFlBQVk7SUFDWixnRUFBZ0U7SUFFaEUsdUJBQXVCO0lBQ3ZCLDJDQUF1QixHQUF2QjtJQUVBLENBQUM7SUFFRCxxQkFBcUI7SUFDckIsMkNBQXVCLEdBQXZCO0lBRUEsQ0FBQztJQUVDLHNCQUFzQjtJQUN4QiwrQkFBVyxHQUFYO0lBRUEsQ0FBQztJQUVELHFDQUFpQixHQUFqQjtJQUVBLENBQUM7SUFFRCx5QkFBSyxHQUFMO0lBRUEsQ0FBQztJQUVELDBCQUFNLEdBQU4sVUFBUSxFQUFFO0lBRVYsQ0FBQztJQXJGRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDOzZDQUNLO0lBRXpCO1FBREMsUUFBUTs2Q0FDWTtJQUVyQjtRQURDLFFBQVE7MENBQ087SUFJaEI7UUFIQyxRQUFRO3VEQUdxQjtJQUU5QjtRQURDLFFBQVE7aURBQ2M7SUFFdkI7UUFEQyxRQUFRO2tEQUNVO0lBbEJGLFNBQVM7UUFqQjdCLE9BQU87UUFFUixvREFBb0Q7UUFFcEQsK0VBQStFO1FBQy9FLG1EQUFtRDtRQUNuRCw2RUFBNkU7UUFDN0UsMkZBQTJGO1FBQzNGLHVFQUF1RTtRQUN2RSxtRUFBbUU7UUFDbkUsaUNBQWlDO1FBQ2pDLCtEQUErRDtRQUMvRCwyQ0FBMkM7UUFDM0Msc0ZBQXNGO1FBQ3RGLHNGQUFzRjtRQUN0RixFQUFFO09BRW1CLFNBQVMsQ0E0RjdCO0lBQUQsZ0JBQUM7Q0E1RkQsQUE0RkMsQ0E1RnNDLEVBQUUsQ0FBQyxTQUFTLEdBNEZsRDtrQkE1Rm9CLFNBQVMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgQ2lyY2xlIH0gZnJvbSBcIi4vQ2lyY2xlXCI7XHJcbmltcG9ydCB7IENlbGwgfSBmcm9tIFwiLi9DZWxsXCI7XHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuXHJcbi8vU2luZ2xldG9uIC0g0L7QtNC40L3QvtGH0LrQsCwg0YPQv9GA0LDQstC70LDRj9GO0YnQsNGPINC40LPRgNC+0LLRi9C8INC/0L7Qu9C10LwsIFxyXG5cclxuLy/RgdC60L7RgNC10Lkg0LLRgdC10LPQviDRgtGD0YIg0LHRg9C00LXRgiDQuCB2aWUsINC80L3QtSDQv9C+0LrQsCDRgtGP0LbQtdC70L4g0L/QtdGA0LXQvtGB0LzRi9GB0LvQuNGC0Ywg0L3QtdC60L7RgtC+0YDRi9C1INCy0LXRidC4INC40LdcclxuLy/QutC+0LrQvtGB0LAsINC90LXQvNC90L7Qs9C+INGA0LXRhNC70LXQutGB0LjQuCwg0LrQvtGC0L7RgNCw0Y8g0LTQvtC70LbQvdCwINC/0L7QvNC+0YfRjDpcclxuLy/QuNC30L3QsNGH0LDQu9GM0L3QviDRjyDQv9C70LDQvdC40YDQvtCy0LDQuyDRgdC+0LfQtNCw0YLRjCDQtNCy0YPRhdC80LXRgNC90YvQuSDQvNCw0YHRgdC40LIg0LrQu9C10YLQvtC6IFtdW10sINC90L4g0LIg0L7RgtC70LjRh9C40LVcclxuLy/QvtGCINGO0L3QuNGC0LggLdC/0L7Rh9C10LzRgy3RgtC+INCyINC60L7QutC+0YHQtSDQvdC10LvRjNC30Y8g0YfQtdGA0LXQtyDQuNC90YHQv9C10LrRgtC+0YAg0LfQsNC/0L7Qu9C90Y/RgtGMINC00LLRg9GF0LzQtdGA0L3Ri9C5INC80LDRgdGB0LjQsiDQvtCx0YrQtdC60YLQsNC80LhcclxuLy8o0LjQu9C4INGPINGC0YPQv9C70Y4/KSwg0LjQvdGB0YLQsNC90YLQuNC90LXQudGC0LjRgtGMINC60YDRg9Cz0LvQtdGI0LrQuCDQsiDQutC70LXRgtC60YMg0Lgg0L7QsdGA0LDRidCw0YLRjNGB0Y8g0Log0L3QuNC8XHJcbi8v0LrQsNC6INC6INC00L7Rh9C10YDQvdC40Lwg0Y3Qu9C10LzQtdC90YLQsNC8LCDRhdGA0LDQvdC40YLRjCDQuCDQv9C+0LvRg9GH0LDRgtGMINCy0YHQtSDQuNC90LTQtdC60YHRiyDQv9C+INC60LvQuNC60YNcclxuLy8gKNC/0L4g0LrQu9C10YLQutC1LNC70LjQsdC+INC/0L4g0LrRgNGD0LPQu9C40YjQutGDKS5cclxuLy/QotCw0Log0LHRiyDQsdGL0LvQviDQuCDQv9GA0L7RidC1INGD0L3QuNGH0YLQvtC20LDRgtGMINC80L7Qu9C90LjRj9C80Lgg0Lgg0LTQtdC70LDRgtGMINC/0YDQvtGH0LjQtSDQstC10YnQuC5cclxuLy/QmtC+0LPQtNCwINC90LUg0L/QvtC70YPRh9C40LvQvtGB0Ywg0YEg0LTQstGD0YXQvNC10YDQvdGL0Lwg0LzQsNGB0YHQuNCy0L7QvFxyXG4vL9GA0LDQt9C80YvRiNC70LXQvdC40Y8g0LTQvtGI0LvQuCDQtNC+INGC0YPQv9C+0Lkg0LHQuNC30L3QtdGBINC70L7Qs9C40LrQuCAtINC/0YDQvtGB0YLQviDRgdC80L7RgtGA0LXRgtGMINGD0LfQu9GLINC4INC+0YIg0Y3RgtC+0LPQviDQuCDQuNCz0YDQsNGC0YwsXHJcbi8v0LLQvtGCLNGB0LXQudGH0LDRgSDQvtC/0Y/RgtGMINC00YPQvNCw0Y4gLSDQstC30Y/RgtGMINC/0L7Qu9C1INGH0LXRgNC10LcgZ2V0Q2hpbGRCeVV1aWQg0Lgg0L/QtdGA0LXQv9C40YHQsNGC0Ywg0LLQtdGB0Ywg0LDQu9Cz0L7RgNC40YLQvC5cclxuLy9cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEdhbWVGaWVsZCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcbiAgICAvL1RPRNCeIC0g0L7Rh9C40YHRgtC40YLRjCDQvtGCINC70LXQs9Cw0YHQuCDQv9C10YDQtdC80LXQvdC90YvRhSDQuCDQutC+0LzQvNC10L3RgtCw0YDQuNC10Lks0L/QvtGB0LvQtSDQv9C10YDQtdC/0LjRgdC60Lgg0LDQu9Cz0L7RgNC40YLQvNCwLlxyXG4gICAgLy/QuNC30LHQsNCy0LjRgtGB0Y8g0L7RgiDQu9C40YjQvdC10Lkg0YDQtdGE0LvQtdC60YHQuNC4LNC30LDQutC10YjQuNGA0L7QstCw0YLRjCDQutC+0LzQv9C+0L3QtdC90YLRiyzRgtCw0Lwg0LPQtNC1INGN0YLQviDQvdC10L7QsdGF0L7QtNC40LzQvi5cclxuICAgIHN0YXRpYyBnYW1lRmllbGQ6IEdhbWVGaWVsZDtcclxuICAgIC8v0LrRgNGD0LbQvtC6INC00LvRjyDQuNC90YHRgtCw0L3RgtC40L3QtdC50YLQsFxyXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcclxuICAgIENpcmNsZTogY2MuUHJlZmFiID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eVxyXG4gICAgY29sdW1uICA6IG51bWJlciA9IDk7XHJcbiAgICBAcHJvcGVydHlcclxuICAgIHJvdzogbnVtYmVyID0gOTtcclxuICAgIEBwcm9wZXJ0eVxyXG4gICAgLy/QutC+0LvQuNGH0LXRgdGC0LLQviDQsNC60YLQuNCy0L3Ri9GFINC60LvQtdGC0L7QulxyXG4gICAgLy8s0LrQvtCz0LTQsCDQv9C10YDQtdC/0LjRiNGDINCw0LvQs9C+0YDQuNGC0Lwg0LPQtdC90LXRgNCw0YbQuNC4IC0g0L3QtSDQv9C+0L3QsNC00L7QsdC40YLRgdGPLlxyXG4gICAgY291bnRBY3RpdmVDZWxsczogbnVtYmVyID0gNjA7XHJcbiAgICBAcHJvcGVydHlcclxuICAgIGNvdW50Q2VsbHM6bnVtYmVyID0gODE7XHJcbiAgICBAcHJvcGVydHlcclxuICAgIGnRgWVsbHM6IG51bWJlciA9IDA7XHJcbiAgICAvL9C/0L7Qu9C1INC60LvQtdGC0L7QulxyXG4gICAgQ2VsbHM6IENlbGxbXVtdPVtcclxuICAgICAgICBbbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGxdLFxyXG4gICAgICAgIFtudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbF0sXHJcbiAgICAgICAgW251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsXSxcclxuICAgICAgICBbbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGxdLFxyXG4gICAgICAgIFtudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbF0sXHJcbiAgICAgICAgW251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsXSxcclxuICAgICAgICBbbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGxdLFxyXG4gICAgICAgIFtudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbF0sXHJcbiAgICBdO1xyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgIC8v0LfQsNC/0L7Qu9C90Y/QtdC8INC/0L7Qu9C1INC60LvQtdGC0LrQsNC80LhcclxuICAgICAgdmFyIGkgOm51bWJlcj0wO1xyXG4gICAgICB2YXIgaiA6bnVtYmVyPTA7XHJcbiAgICAgIHZhciBrIDpudW1iZXI9MDtcclxuICAgICAgZm9yIChqPTA7ajx0aGlzLkNlbGxzLmxlbmd0aDtqKyspICB7XHJcbiAgICAgICAgZm9yKGk9MDtpPHRoaXMuQ2VsbHNbal0ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdGhpcy5DZWxsc1tqXVtpXSA9IHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcIkNlbGxcIiArIGsudG9TdHJpbmcoKSkuZ2V0Q29tcG9uZW50KENlbGwpO1xyXG4gICAgICAgICAgICB0aGlzLkNlbGxzW2pdW2ldLmpjb2x1bW4gPSBqO1xyXG4gICAgICAgICAgICB0aGlzLkNlbGxzW2pdW2ldLmlyb3cgPSBpO1xyXG4gICAgICAgICAgICBrKys7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZ2VuZXJhdG9yQ2lyY2xlKClcclxuICAgIHtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgY3JlYXRlQ2lyY2xlKENlbGwpIHtcclxuICAgICAgICBpZiAoQ2VsbC5nZW5lcmF0b3IgJiYgQ2VsbC5fY2lyY2xlPT1udWxsKSB7XHJcbiAgICAgICAgICAgIENlbGwuX2NpcmNsZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQ2lyY2xlKTtcclxuICAgICAgICAgICAgQ2VsbC5fY2lyY2xlLnNldFBhcmVudCh0aGlzLm5vZGUpO1xyXG4gICAgICAgICAgICBDZWxsLl9jaXJjbGUuc2V0UG9zaXRpb24oMCwgMCk7XHJcbiAgICAgICAgICAgIENlbGwuX2NpcmNsZS5nZXRDb21wb25lbnQoQ2lyY2xlKS5HYW1lRmllbGQ9IENlbGwuR2FtZUZpZWxkO1xyXG4gICAgICAgICAgICBDZWxsLkdhbWVGaWVsZC5p0YFlbGxzKys7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gIFxyXG4gICAgLy9Ub0RvIC0g0YHQvtCx0YvRgtC40LUsINC/0YDQvtCy0LXRgNGP0YLRjCDQv9C+0LvQvdC+0LUg0L/QvtC70LUgLSDQvtGB0YLQsNC90LDQstC70LjQstCw0YLRjCDQs9C10L3QtdGA0LDRhtC40Y4sXHJcbiAgICAvL9C60L7Qs9C00LAg0LLRi9GB0YvQv9Cw0LvQuNGB0Ywg0YTQuNGI0LrRgywg0YDQsNC30YDRg9GI0LDRgtGMINC4INGB0L7Qt9C00LDQstCw0YLRjCDQvNC+0LvQvdC40LggLSDQv9C+0YLQvtC8INGB0L3QvtCy0LAg0L/RgNC+0LTQvtC70LbQsNGC0YxcclxuICAgIC8v0LPQtdC90LXRgNCw0YbQuNGOLlxyXG4gICAgLy/QuNC90LjRhtC40LvQuNC30LjRgNC+0LLQsNGC0Ywg0YHQvtCx0YvRgtC40LUg0L3QsCBkb3dubW91c2UgLSDQv9GA0L7RgNC40YLRjCDRgNGP0LQg0Lgg0L7RgtCy0LXRgtC40YLRjC5cclxuXHJcbiAgICAvL9Cz0L7RgNC40LfQvtC90YLQsNC70YzQvdCw0Y8g0LzQvtC70L3QuNGPXHJcbiAgICBjcmVhdGVMaWdodG5pbmdIb3Jpem9udCgpIHtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgLy/QstC10YDRgtC40LrQsNC70YzQvdCw0Y8g0LzQvtC70L3QuNGPXHJcbiAgICBjcmVhdGVMaWdodG5pbmdWZXJ0aWNhbCgpIHtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgICAvL9Cy0YvRgdGL0L/QsNC70LjRgdGMINGC0YDQuCDQsiDRgNGP0LRcclxuICAgIHRocmVlSW5Bcm93KCkge1xyXG4gICAgIFxyXG4gICAgfVxyXG5cclxuICAgIGNyZWF0ZVJhaW5ib3dCYWxsKCkge1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgIFxyXG4gICAgfVxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgIFxyXG4gICAgfVxyXG59Il19
//------QC-SOURCE-SPLIT------
