
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/GameField.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bfa611mBN1Ato8bmVTiNiGw', 'GameField');
// Script/GameField.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Circle_1 = require("./Circle");
var Cell_1 = require("./Cell");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameField = /** @class */ (function (_super) {
    __extends(GameField, _super);
    //Singleton - одиночка, управлаяющая игровым полем, 
    //скорей всего тут будет и vie, мне пока тяжело переосмыслить некоторые вещи из
    //кокоса, немного рефлексии, которая должна помочь:
    //изначально я планировал создать двухмерный массив клеток [][], но в отличие
    //от юнити -почему-то в кокосе нельзя через инспектор заполнять двухмерный массив объектами
    //(или я туплю?), инстантинейтить круглешки в клетку и обращаться к ним
    //как к дочерним элементам, хранить и получать все индексы по клику
    // (по клетке,либо по круглишку).
    //Так бы было и проще уничтожать молниями и делать прочие вещи.
    //Когда не получилось с двухмерным массивом
    //размышления дошли до тупой бизнес логики - просто смотреть узлы и от этого и играть,
    //вот,сейчас опять думаю - взять поле через getChildByUuid и переписать весь алгоритм.
    //
    function GameField() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //кружок для инстантинейта
        _this.Circle = null;
        _this.column = 9;
        _this.row = 9;
        //количество активных клеток
        //,когда перепишу алгоритм генерации - не понадобится.
        _this.countActiveCells = 60;
        _this.countCells = 81;
        _this.iсells = 0;
        //поле клеток
        _this.Cells = [
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
        ];
        return _this;
    }
    GameField.prototype.onLoad = function () {
        //заполняем поле клетками
        var i = 0;
        var j = 0;
        var k = 0;
        for (j = 0; j < this.Cells.length; j++) {
            for (i = 0; i < this.Cells[j].length; i++) {
                this.Cells[j][i] = this.node.getChildByName("Cell" + k.toString()).getComponent(Cell_1.Cell);
                this.Cells[j][i].jcolumn = j;
                this.Cells[j][i].irow = i;
                k++;
            }
        }
    };
    GameField.prototype.generatorCircle = function () {
    };
    GameField.prototype.createCircle = function (Cell) {
        if (Cell.generator && Cell._circle == null) {
            Cell._circle = cc.instantiate(this.Circle);
            Cell._circle.setParent(this.node);
            Cell._circle.setPosition(0, 0);
            Cell._circle.getComponent(Circle_1.Circle).GameField = Cell.GameField;
            Cell.GameField.iсells++;
        }
    };
    //ToDo - событие, проверять полное поле - останавливать генерацию,
    //когда высыпались фишку, разрушать и создавать молнии - потом снова продолжать
    //генерацию.
    //иницилизировать событие на downmouse - прорить ряд и ответить.
    //горизонтальная молния
    GameField.prototype.createLightningHorizont = function () {
    };
    //вертикальная молния
    GameField.prototype.createLightningVertical = function () {
    };
    //высыпались три в ряд
    GameField.prototype.threeInArow = function () {
    };
    GameField.prototype.createRainbowBall = function () {
    };
    GameField.prototype.start = function () {
    };
    GameField.prototype.update = function (dt) {
    };
    __decorate([
        property(cc.Prefab)
    ], GameField.prototype, "Circle", void 0);
    __decorate([
        property
    ], GameField.prototype, "column", void 0);
    __decorate([
        property
    ], GameField.prototype, "row", void 0);
    __decorate([
        property
    ], GameField.prototype, "countActiveCells", void 0);
    __decorate([
        property
    ], GameField.prototype, "countCells", void 0);
    __decorate([
        property
    ], GameField.prototype, "i\u0441ells", void 0);
    GameField = __decorate([
        ccclass
        //Singleton - одиночка, управлаяющая игровым полем, 
        //скорей всего тут будет и vie, мне пока тяжело переосмыслить некоторые вещи из
        //кокоса, немного рефлексии, которая должна помочь:
        //изначально я планировал создать двухмерный массив клеток [][], но в отличие
        //от юнити -почему-то в кокосе нельзя через инспектор заполнять двухмерный массив объектами
        //(или я туплю?), инстантинейтить круглешки в клетку и обращаться к ним
        //как к дочерним элементам, хранить и получать все индексы по клику
        // (по клетке,либо по круглишку).
        //Так бы было и проще уничтожать молниями и делать прочие вещи.
        //Когда не получилось с двухмерным массивом
        //размышления дошли до тупой бизнес логики - просто смотреть узлы и от этого и играть,
        //вот,сейчас опять думаю - взять поле через getChildByUuid и переписать весь алгоритм.
        //
    ], GameField);
    return GameField;
}(cc.Component));
exports.default = GameField;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxHYW1lRmllbGQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsbUNBQWtDO0FBQ2xDLCtCQUE4QjtBQUN4QixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQW1CMUM7SUFBdUMsNkJBQVk7SUFmbkQsb0RBQW9EO0lBRXBELCtFQUErRTtJQUMvRSxtREFBbUQ7SUFDbkQsNkVBQTZFO0lBQzdFLDJGQUEyRjtJQUMzRix1RUFBdUU7SUFDdkUsbUVBQW1FO0lBQ25FLGlDQUFpQztJQUNqQywrREFBK0Q7SUFDL0QsMkNBQTJDO0lBQzNDLHNGQUFzRjtJQUN0RixzRkFBc0Y7SUFDdEYsRUFBRTtJQUVGO1FBQUEscUVBNEZDO1FBeEZHLDBCQUEwQjtRQUUxQixZQUFNLEdBQWMsSUFBSSxDQUFDO1FBRXpCLFlBQU0sR0FBYSxDQUFDLENBQUM7UUFFckIsU0FBRyxHQUFXLENBQUMsQ0FBQztRQUVoQixBQUVBLDRCQUY0QjtRQUM1QixzREFBc0Q7UUFDdEQsc0JBQWdCLEdBQVcsRUFBRSxDQUFDO1FBRTlCLGdCQUFVLEdBQVUsRUFBRSxDQUFDO1FBRXZCLFlBQU0sR0FBVyxDQUFDLENBQUM7UUFDbkIsYUFBYTtRQUNiLFdBQUssR0FBVztZQUNaLENBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLENBQUM7WUFDOUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksQ0FBQztZQUM5QyxDQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxDQUFDO1lBQzlDLENBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLENBQUM7WUFDOUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksQ0FBQztZQUM5QyxDQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxDQUFDO1lBQzlDLENBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLENBQUM7WUFDOUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsSUFBSSxFQUFDLElBQUksQ0FBQztTQUNqRCxDQUFDOztJQStETixDQUFDO0lBN0RHLDBCQUFNLEdBQU47UUFDRSx5QkFBeUI7UUFDekIsSUFBSSxDQUFDLEdBQVMsQ0FBQyxDQUFDO1FBQ2hCLElBQUksQ0FBQyxHQUFTLENBQUMsQ0FBQztRQUNoQixJQUFJLENBQUMsR0FBUyxDQUFDLENBQUM7UUFDaEIsS0FBSyxDQUFDLEdBQUMsQ0FBQyxFQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBQyxDQUFDLEVBQUUsRUFBRztZQUNqQyxLQUFJLENBQUMsR0FBQyxDQUFDLEVBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNqQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBSSxDQUFDLENBQUM7Z0JBQ3RGLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDO2dCQUMxQixDQUFDLEVBQUUsQ0FBQzthQUNQO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsbUNBQWUsR0FBZjtJQUdBLENBQUM7SUFFRCxnQ0FBWSxHQUFaLFVBQWEsSUFBSTtRQUNiLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFFLElBQUksRUFBRTtZQUN0QyxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzNDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsZUFBTSxDQUFDLENBQUMsU0FBUyxHQUFFLElBQUksQ0FBQyxTQUFTLENBQUM7WUFDNUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztTQUMzQjtJQUNMLENBQUM7SUFFRCxrRUFBa0U7SUFDbEUsK0VBQStFO0lBQy9FLFlBQVk7SUFDWixnRUFBZ0U7SUFFaEUsdUJBQXVCO0lBQ3ZCLDJDQUF1QixHQUF2QjtJQUVBLENBQUM7SUFFRCxxQkFBcUI7SUFDckIsMkNBQXVCLEdBQXZCO0lBRUEsQ0FBQztJQUVDLHNCQUFzQjtJQUN4QiwrQkFBVyxHQUFYO0lBRUEsQ0FBQztJQUVELHFDQUFpQixHQUFqQjtJQUVBLENBQUM7SUFFRCx5QkFBSyxHQUFMO0lBRUEsQ0FBQztJQUVELDBCQUFNLEdBQU4sVUFBUSxFQUFFO0lBRVYsQ0FBQztJQXJGRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDOzZDQUNLO0lBRXpCO1FBREMsUUFBUTs2Q0FDWTtJQUVyQjtRQURDLFFBQVE7MENBQ087SUFJaEI7UUFIQyxRQUFRO3VEQUdxQjtJQUU5QjtRQURDLFFBQVE7aURBQ2M7SUFFdkI7UUFEQyxRQUFRO2tEQUNVO0lBbEJGLFNBQVM7UUFqQjdCLE9BQU87UUFFUixvREFBb0Q7UUFFcEQsK0VBQStFO1FBQy9FLG1EQUFtRDtRQUNuRCw2RUFBNkU7UUFDN0UsMkZBQTJGO1FBQzNGLHVFQUF1RTtRQUN2RSxtRUFBbUU7UUFDbkUsaUNBQWlDO1FBQ2pDLCtEQUErRDtRQUMvRCwyQ0FBMkM7UUFDM0Msc0ZBQXNGO1FBQ3RGLHNGQUFzRjtRQUN0RixFQUFFO09BRW1CLFNBQVMsQ0E0RjdCO0lBQUQsZ0JBQUM7Q0E1RkQsQUE0RkMsQ0E1RnNDLEVBQUUsQ0FBQyxTQUFTLEdBNEZsRDtrQkE1Rm9CLFNBQVMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgQ2lyY2xlIH0gZnJvbSBcIi4vQ2lyY2xlXCI7XHJcbmltcG9ydCB7IENlbGwgfSBmcm9tIFwiLi9DZWxsXCI7XHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuXHJcbi8vU2luZ2xldG9uIC0g0L7QtNC40L3QvtGH0LrQsCwg0YPQv9GA0LDQstC70LDRj9GO0YnQsNGPINC40LPRgNC+0LLRi9C8INC/0L7Qu9C10LwsIFxyXG5cclxuLy/RgdC60L7RgNC10Lkg0LLRgdC10LPQviDRgtGD0YIg0LHRg9C00LXRgiDQuCB2aWUsINC80L3QtSDQv9C+0LrQsCDRgtGP0LbQtdC70L4g0L/QtdGA0LXQvtGB0LzRi9GB0LvQuNGC0Ywg0L3QtdC60L7RgtC+0YDRi9C1INCy0LXRidC4INC40LdcclxuLy/QutC+0LrQvtGB0LAsINC90LXQvNC90L7Qs9C+INGA0LXRhNC70LXQutGB0LjQuCwg0LrQvtGC0L7RgNCw0Y8g0LTQvtC70LbQvdCwINC/0L7QvNC+0YfRjDpcclxuLy/QuNC30L3QsNGH0LDQu9GM0L3QviDRjyDQv9C70LDQvdC40YDQvtCy0LDQuyDRgdC+0LfQtNCw0YLRjCDQtNCy0YPRhdC80LXRgNC90YvQuSDQvNCw0YHRgdC40LIg0LrQu9C10YLQvtC6IFtdW10sINC90L4g0LIg0L7RgtC70LjRh9C40LVcclxuLy/QvtGCINGO0L3QuNGC0LggLdC/0L7Rh9C10LzRgy3RgtC+INCyINC60L7QutC+0YHQtSDQvdC10LvRjNC30Y8g0YfQtdGA0LXQtyDQuNC90YHQv9C10LrRgtC+0YAg0LfQsNC/0L7Qu9C90Y/RgtGMINC00LLRg9GF0LzQtdGA0L3Ri9C5INC80LDRgdGB0LjQsiDQvtCx0YrQtdC60YLQsNC80LhcclxuLy8o0LjQu9C4INGPINGC0YPQv9C70Y4/KSwg0LjQvdGB0YLQsNC90YLQuNC90LXQudGC0LjRgtGMINC60YDRg9Cz0LvQtdGI0LrQuCDQsiDQutC70LXRgtC60YMg0Lgg0L7QsdGA0LDRidCw0YLRjNGB0Y8g0Log0L3QuNC8XHJcbi8v0LrQsNC6INC6INC00L7Rh9C10YDQvdC40Lwg0Y3Qu9C10LzQtdC90YLQsNC8LCDRhdGA0LDQvdC40YLRjCDQuCDQv9C+0LvRg9GH0LDRgtGMINCy0YHQtSDQuNC90LTQtdC60YHRiyDQv9C+INC60LvQuNC60YNcclxuLy8gKNC/0L4g0LrQu9C10YLQutC1LNC70LjQsdC+INC/0L4g0LrRgNGD0LPQu9C40YjQutGDKS5cclxuLy/QotCw0Log0LHRiyDQsdGL0LvQviDQuCDQv9GA0L7RidC1INGD0L3QuNGH0YLQvtC20LDRgtGMINC80L7Qu9C90LjRj9C80Lgg0Lgg0LTQtdC70LDRgtGMINC/0YDQvtGH0LjQtSDQstC10YnQuC5cclxuLy/QmtC+0LPQtNCwINC90LUg0L/QvtC70YPRh9C40LvQvtGB0Ywg0YEg0LTQstGD0YXQvNC10YDQvdGL0Lwg0LzQsNGB0YHQuNCy0L7QvFxyXG4vL9GA0LDQt9C80YvRiNC70LXQvdC40Y8g0LTQvtGI0LvQuCDQtNC+INGC0YPQv9C+0Lkg0LHQuNC30L3QtdGBINC70L7Qs9C40LrQuCAtINC/0YDQvtGB0YLQviDRgdC80L7RgtGA0LXRgtGMINGD0LfQu9GLINC4INC+0YIg0Y3RgtC+0LPQviDQuCDQuNCz0YDQsNGC0YwsXHJcbi8v0LLQvtGCLNGB0LXQudGH0LDRgSDQvtC/0Y/RgtGMINC00YPQvNCw0Y4gLSDQstC30Y/RgtGMINC/0L7Qu9C1INGH0LXRgNC10LcgZ2V0Q2hpbGRCeVV1aWQg0Lgg0L/QtdGA0LXQv9C40YHQsNGC0Ywg0LLQtdGB0Ywg0LDQu9Cz0L7RgNC40YLQvC5cclxuLy9cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEdhbWVGaWVsZCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcbiAgICAvL1RPRNCeIC0g0L7Rh9C40YHRgtC40YLRjCDQvtGCINC70LXQs9Cw0YHQuCDQv9C10YDQtdC80LXQvdC90YvRhSDQuCDQutC+0LzQvNC10L3RgtCw0YDQuNC10Lks0L/QvtGB0LvQtSDQv9C10YDQtdC/0LjRgdC60Lgg0LDQu9Cz0L7RgNC40YLQvNCwLlxyXG4gICAgLy/QuNC30LHQsNCy0LjRgtGB0Y8g0L7RgiDQu9C40YjQvdC10Lkg0YDQtdGE0LvQtdC60YHQuNC4LNC30LDQutC10YjQuNGA0L7QstCw0YLRjCDQutC+0LzQv9C+0L3QtdC90YLRiyzRgtCw0Lwg0LPQtNC1INGN0YLQviDQvdC10L7QsdGF0L7QtNC40LzQvi5cclxuICAgIHN0YXRpYyBnYW1lRmllbGQ6IEdhbWVGaWVsZDtcclxuICAgIC8v0LrRgNGD0LbQvtC6INC00LvRjyDQuNC90YHRgtCw0L3RgtC40L3QtdC50YLQsFxyXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcclxuICAgIENpcmNsZTogY2MuUHJlZmFiID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eVxyXG4gICAgY29sdW1uICA6IG51bWJlciA9IDk7XHJcbiAgICBAcHJvcGVydHlcclxuICAgIHJvdzogbnVtYmVyID0gOTtcclxuICAgIEBwcm9wZXJ0eVxyXG4gICAgLy/QutC+0LvQuNGH0LXRgdGC0LLQviDQsNC60YLQuNCy0L3Ri9GFINC60LvQtdGC0L7QulxyXG4gICAgLy8s0LrQvtCz0LTQsCDQv9C10YDQtdC/0LjRiNGDINCw0LvQs9C+0YDQuNGC0Lwg0LPQtdC90LXRgNCw0YbQuNC4IC0g0L3QtSDQv9C+0L3QsNC00L7QsdC40YLRgdGPLlxyXG4gICAgY291bnRBY3RpdmVDZWxsczogbnVtYmVyID0gNjA7XHJcbiAgICBAcHJvcGVydHlcclxuICAgIGNvdW50Q2VsbHM6bnVtYmVyID0gODE7XHJcbiAgICBAcHJvcGVydHlcclxuICAgIGnRgWVsbHM6IG51bWJlciA9IDA7XHJcbiAgICAvL9C/0L7Qu9C1INC60LvQtdGC0L7QulxyXG4gICAgQ2VsbHM6IENlbGxbXVtdPVtcclxuICAgICAgICBbbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGxdLFxyXG4gICAgICAgIFtudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbF0sXHJcbiAgICAgICAgW251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsXSxcclxuICAgICAgICBbbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGxdLFxyXG4gICAgICAgIFtudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbF0sXHJcbiAgICAgICAgW251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsXSxcclxuICAgICAgICBbbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGxdLFxyXG4gICAgICAgIFtudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbF0sXHJcbiAgICBdO1xyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgIC8v0LfQsNC/0L7Qu9C90Y/QtdC8INC/0L7Qu9C1INC60LvQtdGC0LrQsNC80LhcclxuICAgICAgdmFyIGkgOm51bWJlcj0wO1xyXG4gICAgICB2YXIgaiA6bnVtYmVyPTA7XHJcbiAgICAgIHZhciBrIDpudW1iZXI9MDtcclxuICAgICAgZm9yIChqPTA7ajx0aGlzLkNlbGxzLmxlbmd0aDtqKyspICB7XHJcbiAgICAgICAgZm9yKGk9MDtpPHRoaXMuQ2VsbHNbal0ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdGhpcy5DZWxsc1tqXVtpXSA9IHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcIkNlbGxcIiArIGsudG9TdHJpbmcoKSkuZ2V0Q29tcG9uZW50KENlbGwpO1xyXG4gICAgICAgICAgICB0aGlzLkNlbGxzW2pdW2ldLmpjb2x1bW4gPSBqO1xyXG4gICAgICAgICAgICB0aGlzLkNlbGxzW2pdW2ldLmlyb3cgPSBpO1xyXG4gICAgICAgICAgICBrKys7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZ2VuZXJhdG9yQ2lyY2xlKClcclxuICAgIHtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgY3JlYXRlQ2lyY2xlKENlbGwpIHtcclxuICAgICAgICBpZiAoQ2VsbC5nZW5lcmF0b3IgJiYgQ2VsbC5fY2lyY2xlPT1udWxsKSB7XHJcbiAgICAgICAgICAgIENlbGwuX2NpcmNsZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQ2lyY2xlKTtcclxuICAgICAgICAgICAgQ2VsbC5fY2lyY2xlLnNldFBhcmVudCh0aGlzLm5vZGUpO1xyXG4gICAgICAgICAgICBDZWxsLl9jaXJjbGUuc2V0UG9zaXRpb24oMCwgMCk7XHJcbiAgICAgICAgICAgIENlbGwuX2NpcmNsZS5nZXRDb21wb25lbnQoQ2lyY2xlKS5HYW1lRmllbGQ9IENlbGwuR2FtZUZpZWxkO1xyXG4gICAgICAgICAgICBDZWxsLkdhbWVGaWVsZC5p0YFlbGxzKys7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gIFxyXG4gICAgLy9Ub0RvIC0g0YHQvtCx0YvRgtC40LUsINC/0YDQvtCy0LXRgNGP0YLRjCDQv9C+0LvQvdC+0LUg0L/QvtC70LUgLSDQvtGB0YLQsNC90LDQstC70LjQstCw0YLRjCDQs9C10L3QtdGA0LDRhtC40Y4sXHJcbiAgICAvL9C60L7Qs9C00LAg0LLRi9GB0YvQv9Cw0LvQuNGB0Ywg0YTQuNGI0LrRgywg0YDQsNC30YDRg9GI0LDRgtGMINC4INGB0L7Qt9C00LDQstCw0YLRjCDQvNC+0LvQvdC40LggLSDQv9C+0YLQvtC8INGB0L3QvtCy0LAg0L/RgNC+0LTQvtC70LbQsNGC0YxcclxuICAgIC8v0LPQtdC90LXRgNCw0YbQuNGOLlxyXG4gICAgLy/QuNC90LjRhtC40LvQuNC30LjRgNC+0LLQsNGC0Ywg0YHQvtCx0YvRgtC40LUg0L3QsCBkb3dubW91c2UgLSDQv9GA0L7RgNC40YLRjCDRgNGP0LQg0Lgg0L7RgtCy0LXRgtC40YLRjC5cclxuXHJcbiAgICAvL9Cz0L7RgNC40LfQvtC90YLQsNC70YzQvdCw0Y8g0LzQvtC70L3QuNGPXHJcbiAgICBjcmVhdGVMaWdodG5pbmdIb3Jpem9udCgpIHtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgLy/QstC10YDRgtC40LrQsNC70YzQvdCw0Y8g0LzQvtC70L3QuNGPXHJcbiAgICBjcmVhdGVMaWdodG5pbmdWZXJ0aWNhbCgpIHtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgICAvL9Cy0YvRgdGL0L/QsNC70LjRgdGMINGC0YDQuCDQsiDRgNGP0LRcclxuICAgIHRocmVlSW5Bcm93KCkge1xyXG4gICAgIFxyXG4gICAgfVxyXG5cclxuICAgIGNyZWF0ZVJhaW5ib3dCYWxsKCkge1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgIFxyXG4gICAgfVxyXG5cclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgIFxyXG4gICAgfVxyXG59Il19