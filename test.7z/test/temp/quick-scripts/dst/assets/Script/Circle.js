
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Circle.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7dbc7eE2d1AgKeAG34Dn73t', 'Circle');
// Script/Circle.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Circle = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//класс кружка
var Circle = /** @class */ (function (_super) {
    __extends(Circle, _super);
    function Circle() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //спрайты кружков
        _this.sprite = [];
        //тип фишки
        _this.CircleType = 0;
        return _this;
    }
    //подписываемся на событие клика мышки
    //подумать,где его лучше обрабатывать, может быть в Cell
    Circle.prototype.onLoad = function () {
        this.node.on('mousedown', this.mousedown, this);
    };
    //обрабатываем клик мышки
    //
    Circle.prototype.mousedown = function () {
        //this.wasClick=true;
        this.destroyCircle();
    };
    Circle.prototype.destroyCircle = function () {
        //уничтожение фишки 
        var cell = this.node.getParent();
        cell.getComponent("Cell")._circle = null;
        this.node.destroy();
    };
    Circle.prototype.start = function () {
        //тут случайным образом распределяем спрайты при их появление на сцене 
        var node = new cc.Node('Sprite');
        var sp = node.addComponent(cc.Sprite);
        sp.spriteFrame = this.sprite[Math.floor((Math.random() * 6) + 1)];
        node.parent = this.node;
    };
    __decorate([
        property(cc.SpriteFrame)
    ], Circle.prototype, "sprite", void 0);
    __decorate([
        property
    ], Circle.prototype, "CircleType", void 0);
    Circle = __decorate([
        ccclass
    ], Circle);
    return Circle;
}(cc.Component));
exports.Circle = Circle;
//тип фишки
var typeCircle;
(function (typeCircle) {
    typeCircle[typeCircle["normal"] = 0] = "normal";
    typeCircle[typeCircle["lightningHorizont"] = 1] = "lightningHorizont";
    typeCircle[typeCircle["lightningVertical"] = 2] = "lightningVertical";
    typeCircle[typeCircle["rainbowBall"] = 3] = "rainbowBall";
})(typeCircle || (typeCircle = {}));

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDaXJjbGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQix3RUFBd0U7QUFDeEUsbUJBQW1CO0FBQ25CLGtGQUFrRjtBQUNsRiw4QkFBOEI7QUFDOUIsa0ZBQWtGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRzVFLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBQ3hDLGNBQWM7QUFFZDtJQUE0QiwwQkFBWTtJQUF4QztRQUFBLHFFQXFDQztRQW5DRyxpQkFBaUI7UUFFakIsWUFBTSxHQUFzQixFQUFFLENBQUM7UUFFL0IsQUFDQSxXQURXO1FBQ1gsZ0JBQVUsR0FBZSxDQUFDLENBQUM7O0lBOEIvQixDQUFDO0lBN0JHLHNDQUFzQztJQUN0Qyx3REFBd0Q7SUFDeEQsdUJBQU0sR0FBTjtRQUNFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFRCx5QkFBeUI7SUFDekIsRUFBRTtJQUNGLDBCQUFTLEdBQVQ7UUFDRSxxQkFBcUI7UUFDckIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFFRCw4QkFBYSxHQUFiO1FBQ0Usb0JBQW9CO1FBQ3BCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDakMsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLEdBQUMsSUFBSSxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7SUFFdEIsQ0FBQztJQUVELHNCQUFLLEdBQUw7UUFDRSx1RUFBdUU7UUFDdkUsSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2pDLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RDLEVBQUUsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzFCLENBQUM7SUEvQkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQzswQ0FDTTtJQUcvQjtRQUZDLFFBQVE7OENBRWtCO0lBUGxCLE1BQU07UUFEbEIsT0FBTztPQUNLLE1BQU0sQ0FxQ2xCO0lBQUQsYUFBQztDQXJDRCxBQXFDQyxDQXJDMkIsRUFBRSxDQUFDLFNBQVMsR0FxQ3ZDO0FBckNZLHdCQUFNO0FBc0NuQixXQUFXO0FBQ1gsSUFBSyxVQUtKO0FBTEQsV0FBSyxVQUFVO0lBQ2IsK0NBQVUsQ0FBQTtJQUNWLHFFQUFpQixDQUFBO0lBQ2pCLHFFQUFpQixDQUFBO0lBQ2pCLHlEQUFXLENBQUE7QUFDYixDQUFDLEVBTEksVUFBVSxLQUFWLFVBQVUsUUFLZCIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmltcG9ydCBHYW1lRmllbGQgZnJvbSBcIi4vR2FtZUZpZWxkXCI7XHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG4gIC8v0LrQu9Cw0YHRgSDQutGA0YPQttC60LBcclxuICBAY2NjbGFzc1xyXG4gIGV4cG9ydCBjbGFzcyBDaXJjbGUgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgICAgLy/RgdC/0YDQsNC50YLRiyDQutGA0YPQttC60L7QslxyXG4gICAgICBAcHJvcGVydHkoY2MuU3ByaXRlRnJhbWUpXHJcbiAgICAgIHNwcml0ZTogY2MuU3ByaXRlRnJhbWUgW10gPSBbXTtcclxuICAgICAgQHByb3BlcnR5XHJcbiAgICAgIC8v0YLQuNC/INGE0LjRiNC60LhcclxuICAgICAgQ2lyY2xlVHlwZTogdHlwZUNpcmNsZSA9IDA7XHJcbiAgICAgIC8v0L/QvtC00L/QuNGB0YvQstCw0LXQvNGB0Y8g0L3QsCDRgdC+0LHRi9GC0LjQtSDQutC70LjQutCwINC80YvRiNC60LhcclxuICAgICAgLy/Qv9C+0LTRg9C80LDRgtGMLNCz0LTQtSDQtdCz0L4g0LvRg9GH0YjQtSDQvtCx0YDQsNCx0LDRgtGL0LLQsNGC0YwsINC80L7QttC10YIg0LHRi9GC0Ywg0LIgQ2VsbFxyXG4gICAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMubm9kZS5vbignbW91c2Vkb3duJywgdGhpcy5tb3VzZWRvd24sIHRoaXMpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvL9C+0LHRgNCw0LHQsNGC0YvQstCw0LXQvCDQutC70LjQuiDQvNGL0YjQutC4XHJcbiAgICAgIC8vXHJcbiAgICAgIG1vdXNlZG93bigpIHtcclxuICAgICAgICAvL3RoaXMud2FzQ2xpY2s9dHJ1ZTtcclxuICAgICAgICB0aGlzLmRlc3Ryb3lDaXJjbGUoKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgZGVzdHJveUNpcmNsZSgpe1xyXG4gICAgICAgIC8v0YPQvdC40YfRgtC+0LbQtdC90LjQtSDRhNC40YjQutC4IFxyXG4gICAgICAgIHZhciBjZWxsID0gdGhpcy5ub2RlLmdldFBhcmVudCgpO1xyXG4gICAgICAgIGNlbGwuZ2V0Q29tcG9uZW50KFwiQ2VsbFwiKS5fY2lyY2xlPW51bGw7XHJcbiAgICAgICAgdGhpcy5ub2RlLmRlc3Ryb3koKTtcclxuICAgICAgXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICAvL9GC0YPRgiDRgdC70YPRh9Cw0LnQvdGL0Lwg0L7QsdGA0LDQt9C+0Lwg0YDQsNGB0L/RgNC10LTQtdC70Y/QtdC8INGB0L/RgNCw0LnRgtGLINC/0YDQuCDQuNGFINC/0L7Rj9Cy0LvQtdC90LjQtSDQvdCwINGB0YbQtdC90LUgXHJcbiAgICAgICAgdmFyIG5vZGUgPSBuZXcgY2MuTm9kZSgnU3ByaXRlJyk7XHJcbiAgICAgICAgdmFyIHNwID0gbm9kZS5hZGRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICBzcC5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByaXRlW01hdGguZmxvb3IoKE1hdGgucmFuZG9tKCkgKiA2KSArIDEpXTtcclxuICAgICAgICBub2RlLnBhcmVudCA9IHRoaXMubm9kZTtcclxuICAgICAgfVxyXG4gICAgIFxyXG4gIH0gXHJcbiAgLy/RgtC40L8g0YTQuNGI0LrQuFxyXG4gIGVudW0gdHlwZUNpcmNsZSB7XHJcbiAgICBub3JtYWwgPSAwLFxyXG4gICAgbGlnaHRuaW5nSG9yaXpvbnQsXHJcbiAgICBsaWdodG5pbmdWZXJ0aWNhbCxcclxuICAgIHJhaW5ib3dCYWxsLFxyXG4gIH1cclxuIl19