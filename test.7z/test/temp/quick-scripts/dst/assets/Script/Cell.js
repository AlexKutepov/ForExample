
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Cell.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '93f68rzHqxJY5it62LGw3mz', 'Cell');
// Script/Cell.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Cell = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//TODO переделать алгоритмы генерации. переделать полностью архитекутуру.
var Cell = /** @class */ (function (_super) {
    __extends(Cell, _super);
    //клетка - объект клетки
    function Cell() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //TODO релиз очистить от ненужных переменных и легаси комментариев
        //клетка генератор?
        _this.generator = false;
        //клетка активна? 
        _this.activeself = true;
        //номер строки,где лежит клетка
        _this.irow = 0;
        //номер столбца ,где лежит клетка
        _this.jcolumn = 0;
        //итерация появления фишек
        _this.iter = 0.2;
        //дельта тайм
        _this._timer = 0;
        //кружок для инстантинейта
        _this.Circle = null;
        //кружок в клетке в данный момент
        _this._circle = null;
        //узел с права
        _this.CellRigh = null;
        //узел с лева
        _this.CellLeft = null;
        //узел с верху
        _this.CellTop = null;
        //узел с снизу
        _this.CellBottom = null;
        return _this;
    }
    Cell_1 = Cell;
    Cell.prototype.onLoad = function () {
        //первые шарики появляются тут
        this.createCircle();
    };
    //TODO эту всю логику нужно перенести в GameField т.к.
    //из-за того,что апдейт одновременно выполняется в куче клетках 
    //,не нормально анимировать,не оптимизировать.
    Cell.prototype.update = function (dt) {
        if (this.activeself) {
            // генерация в клетках генераторах
            this.createCircle();
            this._timer += dt;
            //каждую итерацию вызываем движение вниз/вправо, TODO, настроить нормальную анимацию
            //TODO заблокировать поле от кликов,пока идёт генерация.
            if (this._timer >= this.iter) {
                if (this._circle != null) {
                    //TODO выделить повторный код. 
                    if (this.CellBottom != null)
                        if (!this.circleMove(this.CellBottom, this.CellBottom.getComponent(Cell_1))) {
                            if (this.CellRigh != null)
                                if (this.circleMove(this.CellRigh, this.CellRigh.getComponent(Cell_1))) { }
                        }
                }
                this._timer = 0;
            }
        }
    };
    Cell.prototype.createCircle = function () {
        if (this.generator && this._circle == null) {
            this._circle = cc.instantiate(this.Circle);
            this._circle.setParent(this.node);
            this._circle.setPosition(0, 0);
            //cc.log(this.GameField.iсells);
        }
    };
    //p.s. в методе
    //нарушен принцип единственной ответственности.
    Cell.prototype.circleMove = function (Cell, CellComponent) {
        if (Cell != null && CellComponent._circle == null && CellComponent.activeself) {
            var animator = cc.tween;
            CellComponent._circle = this._circle;
            CellComponent._circle.parent = CellComponent.node;
            this._circle = null;
            animator(CellComponent._circle)
                .parallel(animator().to(this.iter - 0.01, { scale: 1 }), animator().to(this.iter - 0.01, { position: cc.v2(0, 0) }))
                .call(function () {
                return;
            })
                .start();
            return true;
        }
        return false;
    };
    Cell.prototype.lateUpdate = function (dt) {
    };
    var Cell_1;
    __decorate([
        property
    ], Cell.prototype, "generator", void 0);
    __decorate([
        property
    ], Cell.prototype, "activeself", void 0);
    __decorate([
        property
    ], Cell.prototype, "iter", void 0);
    __decorate([
        property(cc.Prefab)
    ], Cell.prototype, "Circle", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellRigh", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellLeft", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellTop", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellBottom", void 0);
    Cell = Cell_1 = __decorate([
        ccclass
        //клетка - объект клетки
    ], Cell);
    return Cell;
}(cc.Component));
exports.Cell = Cell;
//клетка на переделку.
var Cell0 = /** @class */ (function () {
    function Cell0(iRow, iColumn) {
        this.generator = false;
        this.activeself = true;
        this.irow = 0;
        this.jcolumn = 0;
        this._circle = null;
        this.irow = iRow;
        this.jcolumn = iColumn;
    }
    return Cell0;
}());

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDZWxsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDTSxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUN4Qyx5RUFBeUU7QUFHM0U7SUFBMEIsd0JBQVk7SUFEdEMsd0JBQXdCO0lBQ3hCO1FBQUEscUVBK0ZDO1FBOUZHLGtFQUFrRTtRQUVsRSxBQUNBLG1CQURtQjtRQUNuQixlQUFTLEdBQVksS0FBSyxDQUFDO1FBRTNCLEFBQ0Esa0JBRGtCO1FBQ2xCLGdCQUFVLEdBQVksSUFBSSxDQUFDO1FBQzNCLCtCQUErQjtRQUMvQixVQUFJLEdBQVEsQ0FBQyxDQUFDO1FBQ2QsaUNBQWlDO1FBQ2pDLGFBQU8sR0FBUSxDQUFDLENBQUM7UUFDakIsMEJBQTBCO1FBRTFCLFVBQUksR0FBVyxHQUFHLENBQUM7UUFDbkIsYUFBYTtRQUNiLFlBQU0sR0FBVyxDQUFDLENBQUM7UUFFbkIsQUFDQSwwQkFEMEI7UUFDMUIsWUFBTSxHQUFjLElBQUksQ0FBQztRQUN6QixpQ0FBaUM7UUFDakMsYUFBTyxHQUFZLElBQUksQ0FBQztRQUV4QixBQUNBLGNBRGM7UUFDZCxjQUFRLEdBQVksSUFBSSxDQUFDO1FBRXpCLEFBQ0EsYUFEYTtRQUNiLGNBQVEsR0FBWSxJQUFJLENBQUM7UUFFdkIsQUFDRixjQURnQjtRQUNoQixhQUFPLEdBQVksSUFBSSxDQUFDO1FBRXRCLEFBQ0YsY0FEZ0I7UUFDaEIsZ0JBQVUsR0FBWSxJQUFJLENBQUM7O0lBOEQvQixDQUFDO2FBL0ZZLElBQUk7SUFrQ2IscUJBQU0sR0FBTjtRQUNJLDhCQUE4QjtRQUM5QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUNELHNEQUFzRDtJQUN0RCxnRUFBZ0U7SUFDaEUsOENBQThDO0lBRTlDLHFCQUFNLEdBQU4sVUFBUSxFQUFFO1FBQ04sSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFHO1lBQ2xCLGtDQUFrQztZQUNsQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDcEIsSUFBSSxDQUFDLE1BQU0sSUFBRSxFQUFFLENBQUM7WUFDaEIsb0ZBQW9GO1lBQ3BGLHdEQUF3RDtZQUN4RCxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUUsSUFBSSxDQUFDLElBQUksRUFBRTtnQkFDeEIsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFFLElBQUksRUFBRTtvQkFDaEIsK0JBQStCO29CQUNuQyxJQUFJLElBQUksQ0FBQyxVQUFVLElBQUUsSUFBSTt3QkFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxNQUFJLENBQUMsQ0FBQyxFQUFFOzRCQUN2RSxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUUsSUFBSTtnQ0FBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxNQUFJLENBQUMsQ0FBQyxFQUFDLEdBQUU7eUJBQXdCO2lCQUMzSDtnQkFDRCxJQUFJLENBQUMsTUFBTSxHQUFDLENBQUMsQ0FBQzthQUNyQjtTQUNKO0lBQ0wsQ0FBQztJQUVELDJCQUFZLEdBQVo7UUFDSSxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE9BQU8sSUFBRSxJQUFJLEVBQUU7WUFDdEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBRS9CLGdDQUFnQztTQUNuQztJQUNMLENBQUM7SUFDRCxlQUFlO0lBQ2YsK0NBQStDO0lBQy9DLHlCQUFVLEdBQVYsVUFBVyxJQUFJLEVBQUUsYUFBYTtRQUMxQixJQUFJLElBQUksSUFBRSxJQUFJLElBQUksYUFBYSxDQUFDLE9BQU8sSUFBRyxJQUFJLElBQUksYUFBYSxDQUFDLFVBQVUsRUFBRTtZQUN4RSxJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDO1lBQ3hCLGFBQWEsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUNyQyxhQUFhLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDO1lBQ2xELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDO2lCQUM5QixRQUFRLENBQ0wsUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUMsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQzNDLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFDLElBQUksRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQzNEO2lCQUNBLElBQUksQ0FBQztnQkFDRixPQUFPO1lBQ1gsQ0FBQyxDQUFDO2lCQUNELEtBQUssRUFBRSxDQUFBO1lBQ1IsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUFDLE9BQU8sS0FBSyxDQUFDO0lBQ25CLENBQUM7SUFFRCx5QkFBVSxHQUFWLFVBQVcsRUFBRTtJQUViLENBQUM7O0lBekZEO1FBRkMsUUFBUTsyQ0FFa0I7SUFHM0I7UUFGQyxRQUFROzRDQUVrQjtJQU8zQjtRQURDLFFBQVE7c0NBQ1U7SUFLbkI7UUFGQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzt3Q0FFSztJQUt6QjtRQUZDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzBDQUVPO0lBR3pCO1FBRkMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7MENBRU87SUFHekI7UUFGQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzt5Q0FFTTtJQUd4QjtRQUZDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzRDQUVTO0lBakNsQixJQUFJO1FBRmhCLE9BQU87UUFDUix3QkFBd0I7T0FDWCxJQUFJLENBK0ZoQjtJQUFELFdBQUM7Q0EvRkQsQUErRkMsQ0EvRnlCLEVBQUUsQ0FBQyxTQUFTLEdBK0ZyQztBQS9GWSxvQkFBSTtBQWlHakIsc0JBQXNCO0FBQ3RCO0lBUUksZUFBWSxJQUFZLEVBQUUsT0FBZTtRQU56QyxjQUFTLEdBQVksS0FBSyxDQUFDO1FBQzNCLGVBQVUsR0FBWSxJQUFJLENBQUM7UUFDbEIsU0FBSSxHQUFRLENBQUMsQ0FBQztRQUNkLFlBQU8sR0FBUSxDQUFDLENBQUM7UUFDMUIsWUFBTyxHQUFZLElBQUksQ0FBQztRQUdwQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztJQUMzQixDQUFDO0lBRUwsWUFBQztBQUFELENBYkEsQUFhQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG4gIC8vVE9ETyDQv9C10YDQtdC00LXQu9Cw0YLRjCDQsNC70LPQvtGA0LjRgtC80Ysg0LPQtdC90LXRgNCw0YbQuNC4LiDQv9C10YDQtdC00LXQu9Cw0YLRjCDQv9C+0LvQvdC+0YHRgtGM0Y4g0LDRgNGF0LjRgtC10LrRg9GC0YPRgNGDLlxyXG5AY2NjbGFzc1xyXG4vL9C60LvQtdGC0LrQsCAtINC+0LHRitC10LrRgiDQutC70LXRgtC60LhcclxuZXhwb3J0IGNsYXNzIENlbGwgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG4gICAgLy9UT0RPINGA0LXQu9C40Lcg0L7Rh9C40YHRgtC40YLRjCDQvtGCINC90LXQvdGD0LbQvdGL0YUg0L/QtdGA0LXQvNC10L3QvdGL0YUg0Lgg0LvQtdCz0LDRgdC4INC60L7QvNC80LXQvdGC0LDRgNC40LXQslxyXG4gICAgQHByb3BlcnR5XHJcbiAgICAvL9C60LvQtdGC0LrQsCDQs9C10L3QtdGA0LDRgtC+0YA/XHJcbiAgICBnZW5lcmF0b3I6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEBwcm9wZXJ0eVxyXG4gICAgLy/QutC70LXRgtC60LAg0LDQutGC0LjQstC90LA/IFxyXG4gICAgYWN0aXZlc2VsZjogYm9vbGVhbiA9IHRydWU7XHJcbiAgICAvL9C90L7QvNC10YAg0YHRgtGA0L7QutC4LNCz0LTQtSDQu9C10LbQuNGCINC60LvQtdGC0LrQsFxyXG4gICAgaXJvdzpudW1iZXI9MDtcclxuICAgIC8v0L3QvtC80LXRgCDRgdGC0L7Qu9Cx0YbQsCAs0LPQtNC1INC70LXQttC40YIg0LrQu9C10YLQutCwXHJcbiAgICBqY29sdW1uOm51bWJlcj0wO1xyXG4gICAgLy/QuNGC0LXRgNCw0YbQuNGPINC/0L7Rj9Cy0LvQtdC90LjRjyDRhNC40YjQtdC6XHJcbiAgICBAcHJvcGVydHlcclxuICAgIGl0ZXI6IG51bWJlciA9IDAuMjtcclxuICAgIC8v0LTQtdC70YzRgtCwINGC0LDQudC8XHJcbiAgICBfdGltZXI6IG51bWJlciA9IDA7XHJcbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxyXG4gICAgLy/QutGA0YPQttC+0Log0LTQu9GPINC40L3RgdGC0LDQvdGC0LjQvdC10LnRgtCwXHJcbiAgICBDaXJjbGU6IGNjLlByZWZhYiA9IG51bGw7XHJcbiAgICAvL9C60YDRg9C20L7QuiDQsiDQutC70LXRgtC60LUg0LIg0LTQsNC90L3Ri9C5INC80L7QvNC10L3RglxyXG4gICAgX2NpcmNsZTogY2MuTm9kZSA9IG51bGw7XHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIC8v0YPQt9C10Lsg0YEg0L/RgNCw0LLQsFxyXG4gICAgQ2VsbFJpZ2g6IGNjLk5vZGUgPSBudWxsO1xyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICAvL9GD0LfQtdC7INGBINC70LXQstCwXHJcbiAgICBDZWxsTGVmdDogY2MuTm9kZSA9IG51bGw7XHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgICAgLy/Rg9C30LXQuyDRgSDQstC10YDRhdGDXHJcbiAgICBDZWxsVG9wOiBjYy5Ob2RlID0gbnVsbDtcclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgICAvL9GD0LfQtdC7INGBINGB0L3QuNC30YNcclxuICAgIENlbGxCb3R0b206IGNjLk5vZGUgPSBudWxsO1xyXG4gICAgb25Mb2FkKCkge1xyXG4gICAgICAgIC8v0L/QtdGA0LLRi9C1INGI0LDRgNC40LrQuCDQv9C+0Y/QstC70Y/RjtGC0YHRjyDRgtGD0YJcclxuICAgICAgICB0aGlzLmNyZWF0ZUNpcmNsZSgpO1xyXG4gICAgfVxyXG4gICAgLy9UT0RPINGN0YLRgyDQstGB0Y4g0LvQvtCz0LjQutGDINC90YPQttC90L4g0L/QtdGA0LXQvdC10YHRgtC4INCyIEdhbWVGaWVsZCDRgi7Qui5cclxuICAgIC8v0LjQty3Qt9CwINGC0L7Qs9C+LNGH0YLQviDQsNC/0LTQtdC50YIg0L7QtNC90L7QstGA0LXQvNC10L3QvdC+INCy0YvQv9C+0LvQvdGP0LXRgtGB0Y8g0LIg0LrRg9GH0LUg0LrQu9C10YLQutCw0YUgXHJcbiAgICAvLyzQvdC1INC90L7RgNC80LDQu9GM0L3QviDQsNC90LjQvNC40YDQvtCy0LDRgtGMLNC90LUg0L7Qv9GC0LjQvNC40LfQuNGA0L7QstCw0YLRjC5cclxuIFxyXG4gICAgdXBkYXRlIChkdCkge1xyXG4gICAgICAgIGlmICh0aGlzLmFjdGl2ZXNlbGYpICB7XHJcbiAgICAgICAgICAgIC8vINCz0LXQvdC10YDQsNGG0LjRjyDQsiDQutC70LXRgtC60LDRhSDQs9C10L3QtdGA0LDRgtC+0YDQsNGFXHJcbiAgICAgICAgICAgIHRoaXMuY3JlYXRlQ2lyY2xlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3RpbWVyKz1kdDtcclxuICAgICAgICAgICAgLy/QutCw0LbQtNGD0Y4g0LjRgtC10YDQsNGG0LjRjiDQstGL0LfRi9Cy0LDQtdC8INC00LLQuNC20LXQvdC40LUg0LLQvdC40Lcv0LLQv9GA0LDQstC+LCBUT0RPLCDQvdCw0YHRgtGA0L7QuNGC0Ywg0L3QvtGA0LzQsNC70YzQvdGD0Y4g0LDQvdC40LzQsNGG0LjRjlxyXG4gICAgICAgICAgICAvL1RPRE8g0LfQsNCx0LvQvtC60LjRgNC+0LLQsNGC0Ywg0L/QvtC70LUg0L7RgiDQutC70LjQutC+0LIs0L/QvtC60LAg0LjQtNGR0YIg0LPQtdC90LXRgNCw0YbQuNGPLlxyXG4gICAgICAgICAgICBpZiAodGhpcy5fdGltZXI+PXRoaXMuaXRlcikge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2NpcmNsZSE9bnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL1RPRE8g0LLRi9C00LXQu9C40YLRjCDQv9C+0LLRgtC+0YDQvdGL0Lkg0LrQvtC0LiBcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5DZWxsQm90dG9tIT1udWxsKVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5jaXJjbGVNb3ZlKHRoaXMuQ2VsbEJvdHRvbSwgdGhpcy5DZWxsQm90dG9tLmdldENvbXBvbmVudChDZWxsKSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuQ2VsbFJpZ2ghPW51bGwpIGlmICh0aGlzLmNpcmNsZU1vdmUodGhpcy5DZWxsUmlnaCwgdGhpcy5DZWxsUmlnaC5nZXRDb21wb25lbnQoQ2VsbCkpKXt9ICAgICAgICAgICAgICAgICAgICAgICB9IFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl90aW1lcj0wOyAgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY3JlYXRlQ2lyY2xlKCkge1xyXG4gICAgICAgIGlmICh0aGlzLmdlbmVyYXRvciAmJiB0aGlzLl9jaXJjbGU9PW51bGwpIHtcclxuICAgICAgICAgICAgdGhpcy5fY2lyY2xlID0gY2MuaW5zdGFudGlhdGUodGhpcy5DaXJjbGUpO1xyXG4gICAgICAgICAgICB0aGlzLl9jaXJjbGUuc2V0UGFyZW50KHRoaXMubm9kZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NpcmNsZS5zZXRQb3NpdGlvbigwLCAwKTtcclxuICAgICAgICAgXHJcbiAgICAgICAgICAgIC8vY2MubG9nKHRoaXMuR2FtZUZpZWxkLmnRgWVsbHMpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC8vcC5zLiDQsiDQvNC10YLQvtC00LVcclxuICAgIC8v0L3QsNGA0YPRiNC10L0g0L/RgNC40L3RhtC40L8g0LXQtNC40L3RgdGC0LLQtdC90L3QvtC5INC+0YLQstC10YLRgdGC0LLQtdC90L3QvtGB0YLQuC5cclxuICAgIGNpcmNsZU1vdmUoQ2VsbCwgQ2VsbENvbXBvbmVudCl7XHJcbiAgICAgICAgaWYgKENlbGwhPW51bGwgJiYgQ2VsbENvbXBvbmVudC5fY2lyY2xlID09bnVsbCAmJiBDZWxsQ29tcG9uZW50LmFjdGl2ZXNlbGYpIHtcclxuICAgICAgICAgICAgbGV0IGFuaW1hdG9yID0gY2MudHdlZW47XHJcbiAgICAgICAgICAgIENlbGxDb21wb25lbnQuX2NpcmNsZSA9IHRoaXMuX2NpcmNsZTtcclxuICAgICAgICAgICAgQ2VsbENvbXBvbmVudC5fY2lyY2xlLnBhcmVudCA9IENlbGxDb21wb25lbnQubm9kZTtcclxuICAgICAgICAgICAgdGhpcy5fY2lyY2xlID0gbnVsbDtcclxuICAgICAgICAgICAgYW5pbWF0b3IoQ2VsbENvbXBvbmVudC5fY2lyY2xlKVxyXG4gICAgICAgICAgICAucGFyYWxsZWwoXHJcbiAgICAgICAgICAgICAgICBhbmltYXRvcigpLnRvKHRoaXMuaXRlci0wLjAxLCB7IHNjYWxlOiAxIH0pLFxyXG4gICAgICAgICAgICAgICAgYW5pbWF0b3IoKS50byh0aGlzLml0ZXItMC4wMSwgeyBwb3NpdGlvbjogY2MudjIoMCwgMCkgfSlcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAuY2FsbCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5zdGFydCgpXHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH0gcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBsYXRlVXBkYXRlKGR0KSB7XHJcbiAgICAgICBcclxuICAgIH1cclxuXHJcbn1cclxuXHJcbi8v0LrQu9C10YLQutCwINC90LAg0L/QtdGA0LXQtNC10LvQutGDLlxyXG5jbGFzcyBDZWxsMCB7XHJcblxyXG4gICAgZ2VuZXJhdG9yOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBhY3RpdmVzZWxmOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHJlYWRvbmx5IGlyb3c6bnVtYmVyPTA7XHJcbiAgICByZWFkb25seSBqY29sdW1uOm51bWJlcj0wO1xyXG4gICAgX2NpcmNsZTogY2MuTm9kZSA9IG51bGw7XHJcbiAgIFxyXG4gICAgY29uc3RydWN0b3IoaVJvdzogbnVtYmVyLCBpQ29sdW1uOiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLmlyb3cgPSBpUm93O1xyXG4gICAgICAgIHRoaXMuamNvbHVtbiA9IGlDb2x1bW47XHJcbiAgICB9XHJcblxyXG59Il19