"use strict";
cc._RF.push(module, 'bfa611mBN1Ato8bmVTiNiGw', 'GameField');
// Script/GameField.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Circle_1 = require("./Circle");
var Cell_1 = require("./Cell");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameField = /** @class */ (function (_super) {
    __extends(GameField, _super);
    //Singleton - одиночка, управлаяющая игровым полем, 
    //скорей всего тут будет и vie, мне пока тяжело переосмыслить некоторые вещи из
    //кокоса, немного рефлексии, которая должна помочь:
    //изначально я планировал создать двухмерный массив клеток [][], но в отличие
    //от юнити -почему-то в кокосе нельзя через инспектор заполнять двухмерный массив объектами
    //(или я туплю?), инстантинейтить круглешки в клетку и обращаться к ним
    //как к дочерним элементам, хранить и получать все индексы по клику
    // (по клетке,либо по круглишку).
    //Так бы было и проще уничтожать молниями и делать прочие вещи.
    //Когда не получилось с двухмерным массивом
    //размышления дошли до тупой бизнес логики - просто смотреть узлы и от этого и играть,
    //вот,сейчас опять думаю - взять поле через getChildByUuid и переписать весь алгоритм.
    //
    function GameField() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //кружок для инстантинейта
        _this.Circle = null;
        _this.column = 9;
        _this.row = 9;
        //количество активных клеток
        //,когда перепишу алгоритм генерации - не понадобится.
        _this.countActiveCells = 60;
        _this.countCells = 81;
        _this.iсells = 0;
        //поле клеток
        _this.Cells = [
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
            [null, null, null, null, null, null, null, null, null],
        ];
        return _this;
    }
    GameField.prototype.onLoad = function () {
        //заполняем поле клетками
        var i = 0;
        var j = 0;
        var k = 0;
        for (j = 0; j < this.Cells.length; j++) {
            for (i = 0; i < this.Cells[j].length; i++) {
                this.Cells[j][i] = this.node.getChildByName("Cell" + k.toString()).getComponent(Cell_1.Cell);
                this.Cells[j][i].jcolumn = j;
                this.Cells[j][i].irow = i;
                k++;
            }
        }
    };
    GameField.prototype.generatorCircle = function () {
    };
    GameField.prototype.createCircle = function (Cell) {
        if (Cell.generator && Cell._circle == null) {
            Cell._circle = cc.instantiate(this.Circle);
            Cell._circle.setParent(this.node);
            Cell._circle.setPosition(0, 0);
            Cell._circle.getComponent(Circle_1.Circle).GameField = Cell.GameField;
            Cell.GameField.iсells++;
        }
    };
    //ToDo - событие, проверять полное поле - останавливать генерацию,
    //когда высыпались фишку, разрушать и создавать молнии - потом снова продолжать
    //генерацию.
    //иницилизировать событие на downmouse - прорить ряд и ответить.
    //горизонтальная молния
    GameField.prototype.createLightningHorizont = function () {
    };
    //вертикальная молния
    GameField.prototype.createLightningVertical = function () {
    };
    //высыпались три в ряд
    GameField.prototype.threeInArow = function () {
    };
    GameField.prototype.createRainbowBall = function () {
    };
    GameField.prototype.start = function () {
    };
    GameField.prototype.update = function (dt) {
    };
    __decorate([
        property(cc.Prefab)
    ], GameField.prototype, "Circle", void 0);
    __decorate([
        property
    ], GameField.prototype, "column", void 0);
    __decorate([
        property
    ], GameField.prototype, "row", void 0);
    __decorate([
        property
    ], GameField.prototype, "countActiveCells", void 0);
    __decorate([
        property
    ], GameField.prototype, "countCells", void 0);
    __decorate([
        property
    ], GameField.prototype, "i\u0441ells", void 0);
    GameField = __decorate([
        ccclass
        //Singleton - одиночка, управлаяющая игровым полем, 
        //скорей всего тут будет и vie, мне пока тяжело переосмыслить некоторые вещи из
        //кокоса, немного рефлексии, которая должна помочь:
        //изначально я планировал создать двухмерный массив клеток [][], но в отличие
        //от юнити -почему-то в кокосе нельзя через инспектор заполнять двухмерный массив объектами
        //(или я туплю?), инстантинейтить круглешки в клетку и обращаться к ним
        //как к дочерним элементам, хранить и получать все индексы по клику
        // (по клетке,либо по круглишку).
        //Так бы было и проще уничтожать молниями и делать прочие вещи.
        //Когда не получилось с двухмерным массивом
        //размышления дошли до тупой бизнес логики - просто смотреть узлы и от этого и играть,
        //вот,сейчас опять думаю - взять поле через getChildByUuid и переписать весь алгоритм.
        //
    ], GameField);
    return GameField;
}(cc.Component));
exports.default = GameField;

cc._RF.pop();