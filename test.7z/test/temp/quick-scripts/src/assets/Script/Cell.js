"use strict";
cc._RF.push(module, '93f68rzHqxJY5it62LGw3mz', 'Cell');
// Script/Cell.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Cell = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//TODO переделать алгоритмы генерации. переделать полностью архитекутуру.
var Cell = /** @class */ (function (_super) {
    __extends(Cell, _super);
    //клетка - объект клетки
    function Cell() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //TODO релиз очистить от ненужных переменных и легаси комментариев
        //клетка генератор?
        _this.generator = false;
        //клетка активна? 
        _this.activeself = true;
        //номер строки,где лежит клетка
        _this.irow = 0;
        //номер столбца ,где лежит клетка
        _this.jcolumn = 0;
        //итерация появления фишек
        _this.iter = 0.2;
        //дельта тайм
        _this._timer = 0;
        //кружок для инстантинейта
        _this.Circle = null;
        //кружок в клетке в данный момент
        _this._circle = null;
        //узел с права
        _this.CellRigh = null;
        //узел с лева
        _this.CellLeft = null;
        //узел с верху
        _this.CellTop = null;
        //узел с снизу
        _this.CellBottom = null;
        return _this;
    }
    Cell_1 = Cell;
    Cell.prototype.onLoad = function () {
        //первые шарики появляются тут
        this.createCircle();
    };
    //TODO эту всю логику нужно перенести в GameField т.к.
    //из-за того,что апдейт одновременно выполняется в куче клетках 
    //,не нормально анимировать,не оптимизировать.
    Cell.prototype.update = function (dt) {
        if (this.activeself) {
            // генерация в клетках генераторах
            this.createCircle();
            this._timer += dt;
            //каждую итерацию вызываем движение вниз/вправо, TODO, настроить нормальную анимацию
            //TODO заблокировать поле от кликов,пока идёт генерация.
            if (this._timer >= this.iter) {
                if (this._circle != null) {
                    //TODO выделить повторный код. 
                    if (this.CellBottom != null)
                        if (!this.circleMove(this.CellBottom, this.CellBottom.getComponent(Cell_1))) {
                            if (this.CellRigh != null)
                                if (this.circleMove(this.CellRigh, this.CellRigh.getComponent(Cell_1))) { }
                        }
                }
                this._timer = 0;
            }
        }
    };
    Cell.prototype.createCircle = function () {
        if (this.generator && this._circle == null) {
            this._circle = cc.instantiate(this.Circle);
            this._circle.setParent(this.node);
            this._circle.setPosition(0, 0);
            //cc.log(this.GameField.iсells);
        }
    };
    //p.s. в методе
    //нарушен принцип единственной ответственности.
    Cell.prototype.circleMove = function (Cell, CellComponent) {
        if (Cell != null && CellComponent._circle == null && CellComponent.activeself) {
            var animator = cc.tween;
            CellComponent._circle = this._circle;
            CellComponent._circle.parent = CellComponent.node;
            this._circle = null;
            animator(CellComponent._circle)
                .parallel(animator().to(this.iter - 0.01, { scale: 1 }), animator().to(this.iter - 0.01, { position: cc.v2(0, 0) }))
                .call(function () {
                return;
            })
                .start();
            return true;
        }
        return false;
    };
    Cell.prototype.lateUpdate = function (dt) {
    };
    var Cell_1;
    __decorate([
        property
    ], Cell.prototype, "generator", void 0);
    __decorate([
        property
    ], Cell.prototype, "activeself", void 0);
    __decorate([
        property
    ], Cell.prototype, "iter", void 0);
    __decorate([
        property(cc.Prefab)
    ], Cell.prototype, "Circle", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellRigh", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellLeft", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellTop", void 0);
    __decorate([
        property(cc.Node)
    ], Cell.prototype, "CellBottom", void 0);
    Cell = Cell_1 = __decorate([
        ccclass
        //клетка - объект клетки
    ], Cell);
    return Cell;
}(cc.Component));
exports.Cell = Cell;
//клетка на переделку.
var Cell0 = /** @class */ (function () {
    function Cell0(iRow, iColumn) {
        this.generator = false;
        this.activeself = true;
        this.irow = 0;
        this.jcolumn = 0;
        this._circle = null;
        this.irow = iRow;
        this.jcolumn = iColumn;
    }
    return Cell0;
}());

cc._RF.pop();