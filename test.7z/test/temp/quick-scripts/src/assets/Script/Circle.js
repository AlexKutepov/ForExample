"use strict";
cc._RF.push(module, '7dbc7eE2d1AgKeAG34Dn73t', 'Circle');
// Script/Circle.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Circle = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
//класс кружка
var Circle = /** @class */ (function (_super) {
    __extends(Circle, _super);
    function Circle() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //спрайты кружков
        _this.sprite = [];
        //тип фишки
        _this.CircleType = 0;
        return _this;
    }
    //подписываемся на событие клика мышки
    //подумать,где его лучше обрабатывать, может быть в Cell
    Circle.prototype.onLoad = function () {
        this.node.on('mousedown', this.mousedown, this);
    };
    //обрабатываем клик мышки
    //
    Circle.prototype.mousedown = function () {
        //this.wasClick=true;
        this.destroyCircle();
    };
    Circle.prototype.destroyCircle = function () {
        //уничтожение фишки 
        var cell = this.node.getParent();
        cell.getComponent("Cell")._circle = null;
        this.node.destroy();
    };
    Circle.prototype.start = function () {
        //тут случайным образом распределяем спрайты при их появление на сцене 
        var node = new cc.Node('Sprite');
        var sp = node.addComponent(cc.Sprite);
        sp.spriteFrame = this.sprite[Math.floor((Math.random() * 6) + 1)];
        node.parent = this.node;
    };
    __decorate([
        property(cc.SpriteFrame)
    ], Circle.prototype, "sprite", void 0);
    __decorate([
        property
    ], Circle.prototype, "CircleType", void 0);
    Circle = __decorate([
        ccclass
    ], Circle);
    return Circle;
}(cc.Component));
exports.Circle = Circle;
//тип фишки
var typeCircle;
(function (typeCircle) {
    typeCircle[typeCircle["normal"] = 0] = "normal";
    typeCircle[typeCircle["lightningHorizont"] = 1] = "lightningHorizont";
    typeCircle[typeCircle["lightningVertical"] = 2] = "lightningVertical";
    typeCircle[typeCircle["rainbowBall"] = 3] = "rainbowBall";
})(typeCircle || (typeCircle = {}));

cc._RF.pop();