
require('./assets/Script/Cell');
require('./assets/Script/Circle');
require('./assets/Script/GameField');
