// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import GameField from "./GameField";
const {ccclass, property} = cc._decorator;
  //класс кружка
  @ccclass
  export class Circle extends cc.Component {

      //спрайты кружков
      @property(cc.SpriteFrame)
      sprite: cc.SpriteFrame [] = [];
      @property
      //тип фишки
      CircleType: typeCircle = 0;
      //подписываемся на событие клика мышки
      //подумать,где его лучше обрабатывать, может быть в Cell
      onLoad () {
        this.node.on('mousedown', this.mousedown, this);
      }

      //обрабатываем клик мышки
      //
      mousedown() {
        //this.wasClick=true;
        this.destroyCircle();
      }

      destroyCircle(){
        //уничтожение фишки 
        var cell = this.node.getParent();
        cell.getComponent("Cell")._circle=null;
        this.node.destroy();
      
      }

      start () {
        //тут случайным образом распределяем спрайты при их появление на сцене 
        var node = new cc.Node('Sprite');
        var sp = node.addComponent(cc.Sprite);
        sp.spriteFrame = this.sprite[Math.floor((Math.random() * 6) + 1)];
        node.parent = this.node;
      }
     
  } 
  //тип фишки
  enum typeCircle {
    normal = 0,
    lightningHorizont,
    lightningVertical,
    rainbowBall,
  }
