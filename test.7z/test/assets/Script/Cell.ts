
const {ccclass, property} = cc._decorator;
  //TODO переделать алгоритмы генерации. переделать полностью архитекутуру.
@ccclass
//клетка - объект клетки
export class Cell extends cc.Component {
    //TODO релиз очистить от ненужных переменных и легаси комментариев
    @property
    //клетка генератор?
    generator: boolean = false;
    @property
    //клетка активна? 
    activeself: boolean = true;
    //номер строки,где лежит клетка
    irow:number=0;
    //номер столбца ,где лежит клетка
    jcolumn:number=0;
    //итерация появления фишек
    @property
    iter: number = 0.2;
    //дельта тайм
    _timer: number = 0;
    @property(cc.Prefab)
    //кружок для инстантинейта
    Circle: cc.Prefab = null;
    //кружок в клетке в данный момент
    _circle: cc.Node = null;
    @property(cc.Node)
    //узел с права
    CellRigh: cc.Node = null;
    @property(cc.Node)
    //узел с лева
    CellLeft: cc.Node = null;
    @property(cc.Node)
      //узел с верху
    CellTop: cc.Node = null;
    @property(cc.Node)
      //узел с снизу
    CellBottom: cc.Node = null;
    onLoad() {
        //первые шарики появляются тут
        this.createCircle();
    }
    //TODO эту всю логику нужно перенести в GameField т.к.
    //из-за того,что апдейт одновременно выполняется в куче клетках 
    //,не нормально анимировать,не оптимизировать.
 
    update (dt) {
        if (this.activeself)  {
            // генерация в клетках генераторах
            this.createCircle();
            this._timer+=dt;
            //каждую итерацию вызываем движение вниз/вправо, TODO, настроить нормальную анимацию
            //TODO заблокировать поле от кликов,пока идёт генерация.
            if (this._timer>=this.iter) {
                if (this._circle!=null) {
                        //TODO выделить повторный код. 
                    if (this.CellBottom!=null)
                    if (!this.circleMove(this.CellBottom, this.CellBottom.getComponent(Cell))) {
                        if (this.CellRigh!=null) if (this.circleMove(this.CellRigh, this.CellRigh.getComponent(Cell))){}                       } 
                    }
                    this._timer=0;  
            }
        }
    }

    createCircle() {
        if (this.generator && this._circle==null) {
            this._circle = cc.instantiate(this.Circle);
            this._circle.setParent(this.node);
            this._circle.setPosition(0, 0);
         
            //cc.log(this.GameField.iсells);
        }
    }
    //p.s. в методе
    //нарушен принцип единственной ответственности.
    circleMove(Cell, CellComponent){
        if (Cell!=null && CellComponent._circle ==null && CellComponent.activeself) {
            let animator = cc.tween;
            CellComponent._circle = this._circle;
            CellComponent._circle.parent = CellComponent.node;
            this._circle = null;
            animator(CellComponent._circle)
            .parallel(
                animator().to(this.iter-0.01, { scale: 1 }),
                animator().to(this.iter-0.01, { position: cc.v2(0, 0) })
            )
            .call(() => {
                return;
            })
            .start()
            return true;
        } return false;
    }
    
    lateUpdate(dt) {
       
    }

}

//клетка на переделку.
class Cell0 {

    generator: boolean = false;
    activeself: boolean = true;
    readonly irow:number=0;
    readonly jcolumn:number=0;
    _circle: cc.Node = null;
   
    constructor(iRow: number, iColumn: number) {
        this.irow = iRow;
        this.jcolumn = iColumn;
    }

}