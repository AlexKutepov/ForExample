
import { Circle } from "./Circle";
import { Cell } from "./Cell";
const {ccclass, property} = cc._decorator;

@ccclass

//Singleton - одиночка, управлаяющая игровым полем, 

//скорей всего тут будет и vie, мне пока тяжело переосмыслить некоторые вещи из
//кокоса, немного рефлексии, которая должна помочь:
//изначально я планировал создать двухмерный массив клеток [][], но в отличие
//от юнити -почему-то в кокосе нельзя через инспектор заполнять двухмерный массив объектами
//(или я туплю?), инстантинейтить круглешки в клетку и обращаться к ним
//как к дочерним элементам, хранить и получать все индексы по клику
// (по клетке,либо по круглишку).
//Так бы было и проще уничтожать молниями и делать прочие вещи.
//Когда не получилось с двухмерным массивом
//размышления дошли до тупой бизнес логики - просто смотреть узлы и от этого и играть,
//вот,сейчас опять думаю - взять поле через getChildByUuid и переписать весь алгоритм.
//

export default class GameField extends cc.Component {
    //TODО - очистить от легаси переменных и комментарией,после переписки алгоритма.
    //избавится от лишней рефлексии,закешировать компоненты,там где это необходимо.
    static gameField: GameField;
    //кружок для инстантинейта
    @property(cc.Prefab)
    Circle: cc.Prefab = null;
    @property
    column  : number = 9;
    @property
    row: number = 9;
    @property
    //количество активных клеток
    //,когда перепишу алгоритм генерации - не понадобится.
    countActiveCells: number = 60;
    @property
    countCells:number = 81;
    @property
    iсells: number = 0;
    //поле клеток
    Cells: Cell[][]=[
        [null,null,null,null,null,null,null,null,null],
        [null,null,null,null,null,null,null,null,null],
        [null,null,null,null,null,null,null,null,null],
        [null,null,null,null,null,null,null,null,null],
        [null,null,null,null,null,null,null,null,null],
        [null,null,null,null,null,null,null,null,null],
        [null,null,null,null,null,null,null,null,null],
        [null,null,null,null,null,null,null,null,null],
    ];

    onLoad () {
      //заполняем поле клетками
      var i :number=0;
      var j :number=0;
      var k :number=0;
      for (j=0;j<this.Cells.length;j++)  {
        for(i=0;i<this.Cells[j].length; i++) {
            this.Cells[j][i] = this.node.getChildByName("Cell" + k.toString()).getComponent(Cell);
            this.Cells[j][i].jcolumn = j;
            this.Cells[j][i].irow = i;
            k++;
        }
      }
    }

    generatorCircle()
    {

    }

    createCircle(Cell) {
        if (Cell.generator && Cell._circle==null) {
            Cell._circle = cc.instantiate(this.Circle);
            Cell._circle.setParent(this.node);
            Cell._circle.setPosition(0, 0);
            Cell._circle.getComponent(Circle).GameField= Cell.GameField;
            Cell.GameField.iсells++;
        }
    }
  
    //ToDo - событие, проверять полное поле - останавливать генерацию,
    //когда высыпались фишку, разрушать и создавать молнии - потом снова продолжать
    //генерацию.
    //иницилизировать событие на downmouse - прорить ряд и ответить.

    //горизонтальная молния
    createLightningHorizont() {

    }

    //вертикальная молния
    createLightningVertical() {

    }

      //высыпались три в ряд
    threeInArow() {
     
    }

    createRainbowBall() {

    }

    start () {
      
    }

    update (dt) {
       
    }
}